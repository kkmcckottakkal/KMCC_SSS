function doPost(e) {
  var response = ContentService.createTextOutput();
  response.setMimeType(ContentService.MimeType.JSON);
  
  // Set CORS headers for all responses
  var headers = response.getHeaders() || {};
  headers['Access-Control-Allow-Origin'] = '*';
  headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS';
  headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization';
  response.setHeaders(headers);
  
  try {
    // Parse the request parameters
    var params = e.parameter;
    var sheetId = params.sheetId;
    var data = JSON.parse(params.data);
    
    // Open the spreadsheet and get the Mobile_Change_Log sheet (GID: 1774598967)
    var spreadsheet = SpreadsheetApp.openById(sheetId);
    var sheet = spreadsheet.getSheetByName('Mobile_Change_Log');
    
    if (!sheet) {
      // If sheet doesn't exist, try to get it by GID
      var sheets = spreadsheet.getSheets();
      for (var i = 0; i < sheets.length; i++) {
        if (sheets[i].getSheetId() == 1774598967) {
          sheet = sheets[i];
          break;
        }
      }
    }
    
    if (!sheet) {
      response.setContent(JSON.stringify({
        error: true,
        message: "Mobile_Change_Log sheet not found"
      }));
      return response;
    }
    
    // Get the last row number to determine the next serial number
    var lastRow = sheet.getLastRow();
    var slNo = lastRow > 1 ? lastRow : 1;
    
    // Prepare the row data for Mobile Change Log
    var rowData = [
      slNo,                    // Sl No
      data.kmccId,             // KMCC_ID
      data.name,               // NAME
      data.oldMobile,          // OLD_MOBILE
      data.newMobile,          // NEW_MOBILE
      data.changedBy,          // CHANGED_BY
      data.changedDt           // CHANGED_DT
    ];
    
    // Append the data to the sheet
    sheet.appendRow(rowData);
    
    response.setContent(JSON.stringify({
      success: true,
      message: "Mobile change record saved successfully",
      data: rowData
    }));
    
    return response;
    
  } catch (error) {
    response.setContent(JSON.stringify({
      error: true,
      message: error.toString()
    }));
    
    return response;
  }
}

// Handle preflight CORS requests
function doOptions(e) {
  var response = ContentService.createTextOutput();
  response.setMimeType(ContentService.MimeType.JSON);
  
  // Set CORS headers
  var headers = response.getHeaders() || {};
  headers['Access-Control-Allow-Origin'] = '*';
  headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS';
  headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization';
  response.setHeaders(headers);
  
  return response;
}