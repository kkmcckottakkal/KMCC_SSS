function doPost(e) {
  var response = ContentService.createTextOutput();
  response.setMimeType(ContentService.MimeType.JSON);
  
  // Set CORS headers for all responses
  var headers = response.getHeaders() || {};
  headers['Access-Control-Allow-Origin'] = '*';
  headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS';
  headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization';
  response.setHeaders(headers);
  
  try {
    // Parse the request parameters
    var params = e.parameter;
    var sheetId = params.sheetId;
    var sheetName = params.sheetName;
    var data = JSON.parse(params.data);
    
    // Open the spreadsheet and get the sheet
    var spreadsheet = SpreadsheetApp.openById(sheetId);
    var sheet = spreadsheet.getSheetByName(sheetName);
    
    if (!sheet) {
      response.setContent(JSON.stringify({
        error: true,
        message: "Sheet not found"
      }));
      return response;
    }
    
    // Get the last row number to determine the next serial number
    var lastRow = sheet.getLastRow();
    var slNo = lastRow > 1 ? lastRow : 1;
    
    // Prepare the row data matching exact column headers
    var rowData = [
      slNo,                    // Sl
      data.idNumber,           // ID Number
      data.name,               // Name
      data.dateTime,           // Time Stamp
      data.remarks,            // Remarks
      data.verifiedBy          // User
    ];
    
    // Append the data to the sheet
    sheet.appendRow(rowData);
    
    response.setContent(JSON.stringify({
      success: true,
      message: "Record saved successfully",
      data: rowData
    }));
    
    return response;
    
  } catch (error) {
    response.setContent(JSON.stringify({
      error: true,
      message: error.toString()
    }));
    
    return response;
  }
}

// Handle preflight CORS requests
function doOptions(e) {
  var response = ContentService.createTextOutput();
  response.setMimeType(ContentService.MimeType.JSON);
  
  // Set CORS headers
  var headers = response.getHeaders() || {};
  headers['Access-Control-Allow-Origin'] = '*';
  headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS';
  headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization';
  response.setHeaders(headers);
  
  return response;
}