import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import ValidationPage from './pages/ValidationPage';
import CancellationListPage from './pages/CancellationListPage';
import ContactUs_5 from './pages/ContactUs';
import Congrats from './pages/ConstituencyList';
import Change_Mobile_no from './pages/ChangeMobilePage';
import CollectionDetailsPage from './pages/CollectionDetailsPage';
import CollectionDetailsPageConstituency from './pages/CollectionDetailsPageConstituency';
import DistrictReceivePage from './pages/DistrictReceivePage';
import StateReceivePage from './pages/StateReceivePage';
import ConstituencyPendingPage from './pages/ConstituencyPendingPage';
import ConstituencyfullPage from './pages/Constituencyfull';
import ConstituencycollectedPage from './pages/Constituencycollected';
import Collectedbyme from './pages/collectedbyme';
import ConstituencyGraph from './pages/Constituencygraphpage';
import ConstituencyCollectedby from './pages/Constituencycollectedby';
import ChangeMobilePage from './pages/ChangeMobilePage';
import ChangeLocationPage from './pages/ChangeLocationPage';
import ChangeMaster from './pages/ChangeMasterData';
import Navigation from './components/Navigation';
import ProtectedRoute from './components/ProtectedRoute';
import DistCollectedbyme from './pages/Distcollectedbyme';
import StateCollectedbyme from './pages/Statecollectedbyme';
import Card_Distribute_Page from './pages/CardDistribute';



function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<LoginPage />} />
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <DashboardPage />
                </>
              </ProtectedRoute>
            }
          />
          <Route
            path="/payment"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <ValidationPage />
                </>
              </ProtectedRoute>
            }
          />
          <Route
            path="/collection-details"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <CollectionDetailsPage />
                </>
              </ProtectedRoute>
            }
          />
          <Route
            path="/collection-details-constituency"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <CollectionDetailsPageConstituency />
                </>
              </ProtectedRoute>
            }
          />
          <Route
            path="/district-receive"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <DistrictReceivePage />
                </>
              </ProtectedRoute>
            }
          />
          <Route
            path="/state-receive"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <StateReceivePage />
                </>
              </ProtectedRoute>
            }
          />
          <Route
            path="/constituency-pending"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <ConstituencyPendingPage />
                </>
              </ProtectedRoute>
            }
          />
           <Route
            path="/constituency-full"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  {/*<ConstituencyPendingPage />*/}
                  <ConstituencyfullPage />
                </>
              </ProtectedRoute>
            }
          />


           <Route
            path="/constituency-collected"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  {/*<ConstituencycollectedPage />*/}
                  <ConstituencycollectedPage />
                </>
              </ProtectedRoute>
            }
          />
          

          <Route
            path="/collected-byme"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <Collectedbyme />
                </>
              </ProtectedRoute>
            }
          />

          <Route
            path="/distcollected-byme"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <DistCollectedbyme />
                </>
              </ProtectedRoute>
            }
          />

        <Route
            path="/stcollected-byme"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <StateCollectedbyme />
                </>
              </ProtectedRoute>
            }
          />
          

          <Route
            path="/congrats_Page"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <Congrats />
                </>
              </ProtectedRoute>
            }
          />
          
          <Route
            path="/Constituency_Graph"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <ConstituencyGraph />
                </>
              </ProtectedRoute>
            }
          />
          <Route
            path="/cancellations"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <CancellationListPage />
                </>
              </ProtectedRoute>
            }
          />
          { /*
          <Route
            path="/Contact-Us"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <ContactUs />
                </>
              </ProtectedRoute>
            }
          />
          */}

        <Route
            path="/ContactUs_Page"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <ContactUs_5 />
                </>
              </ProtectedRoute>
            }
          />

      <Route
            path="/Change_Mobile"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <Change_Mobile_no />
                </>
              </ProtectedRoute>
            }
          />


      <Route
            path="/Change_Master"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <ChangeMaster />
                </>
              </ProtectedRoute>
            }
          />
          
          <Route
            path="/ConstituencyCollected"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <ConstituencyCollectedby />
                </>
              </ProtectedRoute>
            }
          />

          <Route
            path="/change-mobile"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <ChangeMobilePage />
                </>
              </ProtectedRoute>
            }
          />

      <Route
            path="/Change_Location"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <ChangeLocationPage />
                </>
              </ProtectedRoute>
            }
          />

      <Route
            path="/Card_Distribute"
            element={
              <ProtectedRoute>
                <>
                  <Navigation />
                  <Card_Distribute_Page />
                </>
              </ProtectedRoute>
            }
          />
          
         
          
          <Route path="*" element={<Navigate to="/payment" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;