import axios, { AxiosError } from 'axios';
import { VerificationRecord, User } from '../types';


const getSheetsCsvUrl = (sheetId: string, gid: string): string => {
  return `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv&gid=${gid}&timestamp=${Date.now()}&rand=${Math.random()}`;
};

const parseCsv = (csv: string): string[][] => {
  return csv.split('\n')
    .map(line => line.split(',')
    .map(cell => cell.trim().replace(/^["'](.*)["']$/, '$1')));
};

const checkInternetConnection = async (): Promise<boolean> => {
  const endpoints = [
    'https://docs.google.com',
    'https://sheets.googleapis.com',
    'https://www.googleapis.com'
  ];

  try {
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Timeout checking connectivity')), 5000);
    });

    const fetchPromises = endpoints.map(url =>
      fetch(`${url}/favicon.ico`, {
        mode: 'no-cors',
        cache: 'no-cache',
        headers: { 'Cache-Control': 'no-cache' }
      }).then(() => true).catch(() => false)
    );

    const result = await Promise.race([
      Promise.any(fetchPromises),
      timeoutPromise
    ]);

    return !!result;
  } catch (error) {
    return false;
  }
};

const fetchWithRetries = async (url: string, maxRetries = 3) => {
  let retryCount = 0;
  let lastError: Error | null = null;

  while (retryCount < maxRetries) {
    try {
      const isOnline = await checkInternetConnection();
      if (!isOnline) {
        throw new Error('No internet connection. Please check your network and try again.');
      }

      const response = await axios.get(url, {
        headers: {
          'Accept': 'text/csv,text/plain,*/*',
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        },
        timeout: 30000
      });

      if (response.status !== 200) {
        throw new Error('Failed to fetch data from Google Sheets');
      }

      return response;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error('Unknown error occurred');
      retryCount++;
      
      if (retryCount === maxRetries) {
        throw lastError;
      }

      await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
    }
  }
  
  throw lastError || new Error('Failed to connect to Google Sheets');
};

export const validateLoginCredentials = async (id: string, password: string): Promise<User | null> => {
  try {
    //const sheetId = '1HYmkpsA7oNu13rN1xP1kIG8006Hof_50z2ClT4eoOKY';
    const sheetId = '1Qp_PQ0WqkzweQoWhLoomDg8E2uM4foSVWS5UvoqTEyk';
    const gid = '789285851';
    
    const response = await fetchWithRetries(getSheetsCsvUrl(sheetId, gid));
    
   /* if (response?.data) {
      const data = parseCsv(response.data);
      const userRow = data.slice(1).find(row => 
        row[0]?.trim() === id.trim() && row[1]?.trim() === password.trim()
      );
*/

    if (response?.data) {
  const data = parseCsv(response.data);
  const userRow = data.slice(1).find(row => 
    row[0]?.trim().toLowerCase() === id.trim().toLowerCase() &&
    row[1]?.trim().toLowerCase() === password.trim().toLowerCase()
  );

      
      if (userRow) {
        return {
          id: userRow[0],
          password: userRow[1],
          type: userRow[2] || '',
          district: userRow[3] || '',
          constituency: userRow[4] || ''
        };
      }
    }
    
    return null;
  } catch (error) {
    console.error('Login validation error:', error);
    throw new Error('Unable to validate credentials. Please try again.');
  }
};

export const validateKmccId = async (kmccId: string): Promise<any> => {
  try {
    const sheetId = '1Qp_PQ0WqkzweQoWhLoomDg8E2uM4foSVWS5UvoqTEyk';
    const gid = '805376514';
    
    const response = await fetchWithRetries(getSheetsCsvUrl(sheetId, gid));
    
    if (!response?.data) {
      throw new Error('No data received from verification service');
    }
    
    const data = parseCsv(response.data);
    //const matchingRow = data.slice(1).find(row => row[1]?.trim() === kmccId.trim());
   const matchingRow = data.slice(1).find(row =>
        row[1]?.trim() === kmccId.trim() ||
        row[5]?.trim() === kmccId.trim() ||
        row[6]?.trim() === kmccId.trim()
      );


    
    if (matchingRow) {
      return {
        kmccId: matchingRow[1] || '',
        name: matchingRow[2] || '',
        district: matchingRow[3] || '',
        constituency: matchingRow[4] || '',
        civilId: matchingRow[5] || '',
        mobile: matchingRow[6] || '',
        status: matchingRow[8] || '',
        receipt: matchingRow[9] || '',
        collectedBy: matchingRow[10] || '',
        collectedTime: matchingRow[11] || '',
        remarks: matchingRow[13] || '',
        //remarks: [matchingRow[13], matchingRow[8]].filter(Boolean).join(' - '),
        districtCollectedBy: matchingRow[14] || '',
        districtCollectedTime: matchingRow[15] || '',
        stateCollectedBy: matchingRow[16] || '',
        stateCollectedTime: matchingRow[17] || '',
        pending2024: matchingRow[30] || '',
        collectedmobile: matchingRow[31] || '',
        carddistributedyes: matchingRow[35] || '',
        carddistributedname: matchingRow[36] || '',
        location: matchingRow[7] || ''
      };
    }
    
    return null;
  } catch (error) {
    console.error('Error validating KMCC ID:', error);
    throw error;
  }
};

export const getDistrictsAndConstituencies = async (): Promise<{ districts: string[], districtMap: Record<string, string[]> }> => {
  try {
    const sheetId = '1Qp_PQ0WqkzweQoWhLoomDg8E2uM4foSVWS5UvoqTEyk';
    const gid = '1549287959';
    
    const response = await fetchWithRetries(getSheetsCsvUrl(sheetId, gid));
    
    if (!response?.data) {
      throw new Error('No data received from the service');
    }
    
    const data = parseCsv(response.data);
    const rows = data.slice(1).filter(row => row.length >= 2 && row[0]?.trim() && row[1]?.trim()); // Skip header row and ensure valid data
    
    const districts = Array.from(new Set(rows.map(row => row[0].trim()).filter(Boolean)));
    const districtMap: Record<string, string[]> = {};
    
    districts.forEach(district => {
      const constituenciesForDistrict = rows
        .filter(row => row[0].trim() === district)
        .map(row => row[1].trim())
        .filter(Boolean);
      
      if (constituenciesForDistrict.length > 0) {
        districtMap[district] = ['All', ...constituenciesForDistrict];
      } else {
        districtMap[district] = ['All'];
      }
    });
    
    return { 
      districts: ['All', ...districts], 
      districtMap: {
        'All': ['All', ...Array.from(new Set(rows.map(row => row[1].trim()).filter(Boolean)))],
        ...districtMap
      }
    };
  } catch (error) {
    console.error('Error fetching districts and constituencies:', error);
    throw new Error('Failed to load districts and constituencies. Please try again.');
  }
};

interface DistrictSummary {
  district: string;
  totalActiveMembers: number;
  collectedByConstituency: number;
  collectedByDistrict: number;
  collectedByState: number;
}

export const getMemberStatusData = async (district: string = 'All', constituency: string = 'All'): Promise<{ 
  active: number; 
  cancelled: number;
  districtSummary: DistrictSummary[];
  squareReport: {
    constituency: {
      totalReceived: number;
      totalActive: number;
      percentage: number;
    };
    district: {
      totalReceived: number;
      totalActive: number;
      totalReceivedByConstituency: number;
      ratio: number;
    };
    state: {
      totalReceived: number;
      totalActive: number;
      totalReceivedByDistrict: number;
      ratio: number;
    };
  };
}> => {
  try {
    const sheetId = '1Qp_PQ0WqkzweQoWhLoomDg8E2uM4foSVWS5UvoqTEyk';
    const gid = '805376514';
    
    const response = await fetchWithRetries(getSheetsCsvUrl(sheetId, gid));
    
    if (!response?.data) {
      throw new Error('No data received from the service');
    }
    
    const data = parseCsv(response.data);
    const rows = data.slice(1); // Skip header row

    // Filter rows based on district and constituency first
    const filteredRows = rows.filter(row => {
      if (!row[1] || row.every(cell => !cell)) return false;
      
      const rowDistrict = (row[3] || '').trim();
      const rowConstituency = (row[4] || '').trim();
      const status = (row[8] || '').trim().toLowerCase();
      
      if (!status) return false;
      
      if (district === 'All' && constituency === 'All') {
        return true;
      } else if (district === 'All') {
        return rowConstituency === constituency;
      } else if (constituency === 'All') {
        return rowDistrict === district;
      }
      return rowDistrict === district && rowConstituency === constituency;
    });

    // Calculate active and cancelled counts
    const active = filteredRows.filter(row => 
      (row[8] || '').trim().toLowerCase() === 'active'
    ).length;

    const cancelled = filteredRows.filter(row => 
      (row[8] || '').trim().toLowerCase() === 'cancelled'
    ).length;

    // Process district summary
    const districtMap = new Map<string, DistrictSummary>();
    
    // Only process active rows for the summary
    const activeRows = filteredRows.filter(row => 
      (row[8] || '').trim().toLowerCase() === 'active'
    );

    // Get unique districts from filtered rows
    const uniqueDistricts = Array.from(new Set(activeRows.map(row => (row[3] || '').trim())));

    // Initialize summary for each district
    uniqueDistricts.forEach(dist => {
      districtMap.set(dist, {
        district: dist,
        totalActiveMembers: 0,
        collectedByConstituency: 0,
        collectedByDistrict: 0,
        collectedByState: 0
      });
    });

    // Calculate statistics for each district
    activeRows.forEach(row => {
      const rowDistrict = (row[3] || '').trim();
      const summary = districtMap.get(rowDistrict)!;
      
      summary.totalActiveMembers++;
      if ((row[9] || '').trim()) summary.collectedByConstituency++;
      if ((row[14] || '').trim()) summary.collectedByDistrict++;
      if ((row[16] || '').trim()) summary.collectedByState++;
    });

    // Convert to array and sort by total active members
    const districtSummary = Array.from(districtMap.values())
      .sort((a, b) => b.totalActiveMembers - a.totalActiveMembers);

    // Calculate totals
    if (districtSummary.length > 0) {
      const totalRow = {
        district: 'Total',
        totalActiveMembers: districtSummary.reduce((sum, d) => sum + d.totalActiveMembers, 0),
        collectedByConstituency: districtSummary.reduce((sum, d) => sum + d.collectedByConstituency, 0),
        collectedByDistrict: districtSummary.reduce((sum, d) => sum + d.collectedByDistrict, 0),
        collectedByState: districtSummary.reduce((sum, d) => sum + d.collectedByState, 0)
      };
      
      // Only add total row if there are districts to summarize
      if (districtSummary.length > 0) {
        districtSummary.push(totalRow);
      }
    }

    // Calculate square report statistics
    const constituencyCollected = activeRows.filter(row => (row[9] || '').trim()).length;
    const districtCollected = activeRows.filter(row => (row[14] || '').trim()).length;
    const stateCollected = activeRows.filter(row => (row[16] || '').trim()).length;
    const totalActiveFiltered = activeRows.length;

    return {
      active,
      cancelled,
      districtSummary,
      squareReport: {
        constituency: {
          totalReceived: constituencyCollected,
          totalActive: totalActiveFiltered,
          percentage: totalActiveFiltered > 0 ? (constituencyCollected / totalActiveFiltered) * 100 : 0
        },
        district: {
          totalReceived: districtCollected,
          totalActive: totalActiveFiltered,
          totalReceivedByConstituency: constituencyCollected,
          ratio: constituencyCollected > 0 ? (districtCollected / constituencyCollected) * 100 : 0
        },
        state: {
          totalReceived: stateCollected,
          totalActive: totalActiveFiltered,
          totalReceivedByDistrict: districtCollected,
          ratio: districtCollected > 0 ? (stateCollected / districtCollected) * 100 : 0
        }
      }
    };
  } catch (error) {
    console.error('Error fetching member status data:', error);
    throw error;
  }
};

export const saveVerificationRecord = async (record: Omit<VerificationRecord, 'slNo' | 'receipt'>): Promise<boolean> => {
  try {
    const sheetId = '1Qp_PQ0WqkzweQoWhLoomDg8E2uM4foSVWS5UvoqTEyk';
    const sheetName = 'Collection_2025';
    
    if (!record.idNumber || !record.name || !record.verifiedBy) {
      throw new Error('Missing required fields for verification record');
    }

    const scriptUrl = 'https://script.google.com/macros/s/AKfycbw-RtApp2U1EmiVa3V_C5cFF_IhaYeWpzwbf8giRZ8z0hcYiOpROcImGqZ-kMPz1HX4/exec';

    const formData = new URLSearchParams();
    formData.append('sheetId', sheetId);
    formData.append('sheetName', sheetName);
    formData.append('data', JSON.stringify({
      idNumber: record.idNumber,
      name: record.name,
      dateTime: new Date().toLocaleString('en-US', { timeZone: 'Asia/Kuwait' }),
      remarks: record.remarks || '',
      verifiedBy: record.verifiedBy
    }));

    const response = await axios({
      method: 'post',
      url: scriptUrl,
      data: formData,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': '*/*',
        'Origin': window.location.origin
      },
      timeout: 30000
    });

    if (response.data?.error) {
      //throw new Error(response.data.message || 'Failed to save verification record');
    }

    return true;
  } catch (error: any) {
    if (error.response?.data?.error) {
      //throw new Error(error.response.data.message || 'Failed to save verification record');
    }
    if (error.code === 'ECONNABORTED') {
      throw new Error('The save operation timed out. The record might have been saved, please check before trying again.');
    }
    //throw new Error('Failed to save verification record. Please try again.');
  }
};

export const saveDistrictReceiveRecord = async (record: Omit<VerificationRecord, 'slNo' | 'receipt'>): Promise<boolean> => {
  try {
    const sheetId = '1Qp_PQ0WqkzweQoWhLoomDg8E2uM4foSVWS5UvoqTEyk';
    const sheetName = 'District Collection';
    
    if (!record.idNumber || !record.name || !record.verifiedBy) {
      throw new Error('Missing required fields for verification record');
    }

    const scriptUrl = 'https://script.google.com/macros/s/AKfycbw-RtApp2U1EmiVa3V_C5cFF_IhaYeWpzwbf8giRZ8z0hcYiOpROcImGqZ-kMPz1HX4/exec';

    const formData = new URLSearchParams();
    formData.append('sheetId', sheetId);
    formData.append('sheetName', sheetName);
    formData.append('data', JSON.stringify({
      idNumber: record.idNumber,
      name: record.name,
      dateTime: new Date().toLocaleString('en-US', { timeZone: 'Asia/Kuwait' }),
      remarks: record.remarks || '',
      verifiedBy: record.verifiedBy
    }));

    const response = await axios({
      method: 'post',
      url: scriptUrl,
      data: formData,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': '*/*',
        'Origin': window.location.origin
      },
      timeout: 30000
    });

    if (response.data?.error) {
      throw new Error(response.data.message || 'Failed to save district receive record');
    }

    return true;
  } catch (error: any) {
    if (error.response?.data?.error) {
      throw new Error(error.response.data.message || 'Failed to save district receive record');
    }
    if (error.code === 'ECONNABORTED') {
      throw new Error('The save operation timed out. The record might have been saved, please check before trying again.');
    }
    //throw new Error('Failed to save district receive record. Please try again.');
  }
};

export const saveStateReceiveRecord = async (record: Omit<VerificationRecord, 'slNo' | 'receipt'>): Promise<boolean> => {
  try {
    const sheetId = '1Qp_PQ0WqkzweQoWhLoomDg8E2uM4foSVWS5UvoqTEyk';
    const sheetName = 'State Collection';
    
    if (!record.idNumber || !record.name || !record.verifiedBy) {
      throw new Error('Missing required fields for verification record');
    }

    const scriptUrl = 'https://script.google.com/macros/s/AKfycbw-RtApp2U1EmiVa3V_C5cFF_IhaYeWpzwbf8giRZ8z0hcYiOpROcImGqZ-kMPz1HX4/exec';

    const formData = new URLSearchParams();
    formData.append('sheetId', sheetId);
    formData.append('sheetName', sheetName);
    formData.append('data', JSON.stringify({
      idNumber: record.idNumber,
      name: record.name,
      dateTime: new Date().toLocaleString('en-US', { timeZone: 'Asia/Kuwait' }),
      remarks: record.remarks || '',
      verifiedBy: record.verifiedBy
    }));

    const response = await axios({
      method: 'post',
      url: scriptUrl,
      data: formData,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': '*/*',
        'Origin': window.location.origin
      },
      timeout: 30000
    });

    if (response.data?.error) {
      throw new Error(response.data.message || 'Failed to save state receive record');
    }

    return true;
  } catch (error: any) {
    if (error.response?.data?.error) {
      throw new Error(error.response.data.message || 'Failed to save state receive record');
    }
    if (error.code === 'ECONNABORTED') {
      throw new Error('The save operation timed out. The record might have been saved, please check before trying again.');
    }
    //throw new Error('Failed to save state receive record. Please try again.');
  }
};

export const saveMobileChangeRecord = async (record: {
  kmccId: string;
  name: string;
  oldMobile: string;
  newMobile: string;
  changedBy: string;
  changedDt: string;
}): Promise<boolean> => {
  try {
    const sheetId = '1Qp_PQ0WqkzweQoWhLoomDg8E2uM4foSVWS5UvoqTEyk';
    const sheetName = 'Mobile_Change';
    
    if (!record.kmccId || !record.name || !record.newMobile || !record.changedBy) {
      throw new Error('Missing required fields for mobile change record');
    }

    //const scriptUrl = 'https://script.google.com/macros/s/AKfycbx3RGXJXXu60b_9jJMLaQsayu9Hw_ElFHhKbUJggyq0RhM9ZDoZc3SmEHf8kKMojenh/exec';
    const scriptUrl = 'https://script.google.com/macros/s/AKfycbwmuen9f16i1y7z1keDTsOXj8tif_fxrczj7-KkXHT9Crw1Oc5atha8pSXFEpbBU6l-/exec';
    

    const formData = new URLSearchParams();
    formData.append('sheetId', sheetId);
    formData.append('sheetName', sheetName);
    formData.append('data', JSON.stringify(record));

    const response = await axios({
      method: 'post',
      url: scriptUrl,
      data: formData,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': '*/*',
        'Origin': window.location.origin
      },
      timeout: 30000
    });

    if (response.data?.error) {
      throw new Error(response.data.message || 'Failed to save mobile change record');
    }

    return true;
  } catch (error: any) {
    if (error.response?.data?.error) {
      throw new Error(error.response.data.message || 'Failed to save mobile change record');
    }
    if (error.code === 'ECONNABORTED') {
      throw new Error('The save operation timed out. The record might have been saved, please check before trying again.');
    }
    throw new Error('Failed to save mobile change record. Please try again.');
  }
};





export const saveLocationChangeRecord = async (record: {
  kmccId: string;
  name: string;
  oldLocation: string;
  newLocation: string;
  changedBy: string;
  changedDt: string;
}): Promise<boolean> => {
  try {
    const sheetId = '1Qp_PQ0WqkzweQoWhLoomDg8E2uM4foSVWS5UvoqTEyk';
    const sheetName = 'Location_Change';
    
    if (!record.kmccId || !record.name || !record.newLocation || !record.changedBy) {
      throw new Error('Missing required fields for mobile change record');
    }

    //const scriptUrl = 'https://script.google.com/macros/s/AKfycbx3RGXJXXu60b_9jJMLaQsayu9Hw_ElFHhKbUJggyq0RhM9ZDoZc3SmEHf8kKMojenh/exec';
    const scriptUrl = 'https://script.google.com/macros/s/AKfycby585SGqDVQlgedEWWAJjcvBAalnNtccOME4TbT59_tYgc2m1RfhSGSYBcaYxG4ZVNM/exec';
    

    const formData = new URLSearchParams();
    formData.append('sheetId', sheetId);
    formData.append('sheetName', sheetName);
    formData.append('data', JSON.stringify(record));

    const response = await axios({
      method: 'post',
      url: scriptUrl,
      data: formData,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': '*/*',
        'Origin': window.location.origin
      },
      timeout: 30000
    });

    if (response.data?.error) {
      throw new Error(response.data.message || 'Failed to save Location change record');
    }

    return true;
  } catch (error: any) {
    if (error.response?.data?.error) {
      throw new Error(error.response.data.message || 'Failed to save Location change record');
    }
    if (error.code === 'ECONNABORTED') {
      throw new Error('The save operation timed out. The record might have been saved, please check before trying again.');
    }
    throw new Error('Failed to save Location change record. Please try again.');
  }
};



export const saveCardDistributed = async (record: {
  kmccId: string;
  name: string;
  changedBy: string;
  changedDt: string;
}): Promise<boolean> => {
  
       //const scriptUrl = 'https://script.google.com/macros/s/AKfycbx3RGXJXXu60b_9jJMLaQsayu9Hw_ElFHhKbUJggyq0RhM9ZDoZc3SmEHf8kKMojenh/exec';
    //const scriptUrl = 'https://script.google.com/macros/s/AKfycbwiJK6x63rz8CakFsPM_JZBFtRfsjn0KgG5kZETZXOA2d7JuVt0yOqiJiMADyZWSXLW/exec';
    const scriptUrl = 'https://script.google.com/macros/s/AKfycbwT1zP36_CGQWKPeLTG32dRVb_dpLX6gdjHUphG3XbCsYnDGjnum9FlIas-UI5mgSc/exec';


    const response = await fetch(scriptUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
    body: JSON.stringify(record),
  });

  const data = await response.json();
  return data?.status === 'success';
};

/*
export const saveLocationChangeRecord = async (record: {
  kmccId: string;
  name: string;
  oldLocation: string;
  newLocation: string;
  changedBy: string;
  changedDt: string;
}): Promise<boolean> => {
  try {
    const sheetId = '1Qp_PQ0WqkzweQoWhLoomDg8E2uM4foSVWS5UvoqTEyk';
    const sheetName = 'Location_Change';

    if (!record.kmccId || !record.name || !record.newLocation || !record.changedBy) {
      throw new Error('Missing required fields for location change record');
    }

    const scriptUrl = 'https://script.google.com/macros/s/AKfycby585SGqDVQlgedEWWAJjcvBAalnNtccOME4TbT59_tYgc2m1RfhSGSYBcaYxG4ZVNM/exec';

    const formData = new URLSearchParams();
    formData.append('sheetId', sheetId);
    formData.append('sheetName', sheetName);
    formData.append('data', JSON.stringify(record));

    const response = await axios.post(scriptUrl, formData, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': '*\/  *',
        'Origin': window.location.origin
      },
      timeout: 30000
    });

    if (response.data?.error) {
      throw new Error(response.data.message || 'Failed to save Location change record');
    }

    return true;
  } catch (error: any) {
    if (error.response?.data?.error) {
      throw new Error(error.response.data.message || 'Failed to save Location change record');
    }
    if (error.code === 'ECONNABORTED') {
      throw new Error('The save operation timed out. The record might have been saved, please check before trying again.');
    }
    throw new Error('Failed to save Location change record. Please try again.');
  }
};
*/