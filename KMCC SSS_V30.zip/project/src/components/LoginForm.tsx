import React, { useState } from 'react';
import { User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { validateLoginCredentials } from '../utils/sheetsApi';
import { useAuth } from '../context/AuthContext';

const LoginForm: React.FC = () => {
  const [id, setId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { login } = useAuth();
  const { logout, authState } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const user = await validateLoginCredentials(id, password);
      const isAdmin = authState.user?.type === 'Admin';
      const isState = authState.user?.type === 'State';
      const isDistrict = authState.user?.type === 'District';
      const isST = authState.user?.type === 'ST';
      const isConstituency = authState.user?.type === 'Constituency';
      const isCardDistribute = authState.user?.type === 'IDCard';
      
            
      if (user) {
        login(user);
        navigate('/payment');
        if (user.type === 'IDCard') {
              navigate('/Card_Distribute');
            } else {
              navigate('/payment');
            }
      } else {
        setError('Invalid ID or password. Please check your credentials and try again.');
      }
    } catch (err: any) {
      let errorMessage = err.message || 'An error occurred while trying to log in.';
      
      if (!errorMessage.includes('Network Error')) {
        if (errorMessage.includes('timeout')) {
          errorMessage = 'Network Error: The authentication service is taking too long to respond. Please try again.';
        } else if (errorMessage.includes('restricted')) {
          errorMessage = 'Network Error: Access to the authentication service is currently restricted. Please try again later or contact support.';
        }
      }
      
      setError(errorMessage);
      console.error('Login error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md p-6 bg-white rounded-lg shadow-md">
      <div className="flex flex-col items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800 mt-4">Login</h2>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-md text-sm">
          {error}
        </div>
      )}


      
      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label htmlFor="id" className="block text-sm font-medium text-gray-700 mb-1">
            ID
          </label>
          <input
            id="id"
            type="text"
            value={id}
            onChange={(e) => setId(e.target.value)}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
            placeholder="Enter your ID"
          />
        </div>

        <div>
          <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
            Password
          </label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
            placeholder="Enter your password"
            
          />
        </div>

        
              
        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2.5 rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-70"
        >
          {isLoading ? (
          
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Loading...
            </span>
          ) : (
            'Login'
          )}
        </button>
      </form>
    </div>
  );
};

export default LoginForm;