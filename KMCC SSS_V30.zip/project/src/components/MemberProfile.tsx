	import React, { useState } from 'react';
	import { useAuth } from '../context/AuthContext';
	import { User, MapPin, Building, CreditCard, Phone, Save, Receipt, UserCheck, Clock, MessageSquare } from 'lucide-react';
	import { saveVerificationRecord, validateKmccId } from '../utils/sheetsApi';
	import ReceiptComponent from './Receipt';
	import {CheckCircle, XCircle } from 'lucide-react';
  import { saveCardDistributed } from '../utils/sheetsApi';
	
	
	const MemberProfile: React.FC = () => {
	  const { authState, setMember } = useAuth();
	  const { member, user } = authState;
	  const [newMobile, setNewMobile] = useState('');
	  const [remarks, setRemarks] = useState('');
	  const [isSaving, setIsSaving] = useState(false);
	  const [saveError, setSaveError] = useState('');
	  const [saveSuccess, setSaveSuccess] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
	
	  if (!member) return null;
	
	  const isAlreadyCollected = member.receipt && member.receipt.length > 10;
	  const isCancelled = member.status === 'Cancelled';
	  const isPending =  member.pending2024 === '2024 Pending';
	
	
	  const revalidateKmccId = async () => {
	    try {
	      const updatedMember = await validateKmccId(member.kmccId);
	      if (updatedMember) {
	        setMember(updatedMember);
	      }
	    } catch (error) {
	      console.error('Error revalidating KMCC ID:', error);
	    }
	  };

// ID Card Saving Function Start
     const handleSaveID = async () => {
          if (!member) return;
          setIsSaving(true); setError(''); setSuccess('');
          try {
            await saveCardDistributed({
              kmccId: member.kmccId,
              name: member.name,
              changedBy: authState.user?.id || '',
              changedDt: new Date().toISOString(),
            });
            setSuccess('Card Distribution recorded successfully!');
            //setMemberData(null);
            //setSearchValue('');
            await revalidateKmccId();
          } catch (e) {
            console.error(e);
            setError('Failed to save record. Please try again.');
          } finally {
            setIsSaving(false);
            setTimeout(() => {
              setError('');
              setSuccess('');
            }, 5000);
          }
        };
// ID Card Saving Function End


    
	  const handleSave = async () => {
	    if (isAlreadyCollected) return;
	    
	    setIsSaving(true);
	    setSaveError('');
	    setSaveSuccess(false);
	
	    try {
	      await saveVerificationRecord({
	        idNumber: member.kmccId,
	        name: member.name,
	        dateTime: new Date().toLocaleString('en-US', { timeZone: 'Asia/Kuwait' }),
	        remarks: remarks,
	        verifiedBy: user?.id || ''
	      });
	
	      setSaveSuccess(true);
	      setRemarks('');
	      
	      setTimeout(() => {
	        setSaveSuccess(false);
	      }, 3000);
	    } catch (error: any) {
	      setSaveError(error.message || 'An error occurred while saving');
	      
	      setTimeout(() => {
	        setSaveError('');
	      }, 3000);
	    } finally {
	      setIsSaving(false);
	      await revalidateKmccId();
	    }
	  };
	
	  return (
	    //<div className="w-full max-w-md mt-6 p-6 bg-white rounded-lg shadow-md">
	    //<div className={`w-full max-w-md mt-6 p-6 rounded-lg shadow-md ${isPending ? 'bg-pink-100' : 'bg-white'}`}>
	<div className={`w-full max-w-md mt-6 p-6 rounded-lg shadow-md
	  ${isPending ? 'bg-pink-100' : isAlreadyCollected ? 'bg-green-100' : 'bg-white'}`}>
	  
	      <h3 className="text-xl font-semibold text-gray-800 mb-4">Member Information</h3>
	      
	      <div className="space-y-4">
	
	        <div className="flex flex-col sm:flex-row sm:space-x-6">
              <div className="flex-1 flex items-start mb-4 sm:mb-0">
                <div className="mt-0.5 mr-3 text-blue-600">
                  <User size={18} />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">KMCC ID</p>
                  <p className="text-base font-medium text-gray-800">{member.kmccId}</p>
                </div>
              </div>
            
              <div className="flex-1 flex items-start">
                <div className="mt-0.5 mr-3 text-blue-600">
                  <User size={18} />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Name</p>
                  <p className="text-base font-medium text-gray-800">{member.name}</p>
                </div>
              </div>
            </div>

          
	        
	        <div className="flex flex-col sm:flex-row sm:space-x-6">
              <div className="flex-1 flex items-start mb-4 sm:mb-0">
                <div className="mt-0.5 mr-3 text-blue-600">
                  <MapPin size={18} />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">District</p>
                  <p className="text-base font-medium text-gray-800">{member.district}</p>
                </div>
              </div>
            
              <div className="flex-1 flex items-start">
                <div className="mt-0.5 mr-3 text-blue-600">
                  <Building size={18} />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Constituency</p>
                  <p className="text-base font-medium text-gray-800">{member.constituency}</p>
                </div>
              </div>
            </div>

	        
	        <div className="flex flex-col sm:flex-row sm:space-x-6">
            {/* Civil ID */}
            <div className="flex-1 flex items-start mb-4 sm:mb-0">
              <div className="mt-0.5 mr-3 text-blue-600">
                <CreditCard size={18} />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Civil ID</p>
                <p className="text-base font-medium text-gray-800">
                  {member.civilId}
                </p>
              </div>
            </div>
          
            {/* Mobile */}
            <div className="flex-1 flex items-start">
              <div className="mt-0.5 mr-3 text-blue-600">
                <Phone size={18} />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Mobile</p>
                <p className="text-base font-medium text-gray-800">
                  <a
                    href={`https://wa.me/965${member.mobile.replace(/\D/g, '')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-green-600 hover:underline"
                  >
                    {member.mobile}
                  </a>
                  {member.status && ` - ${member.status}`}
                  {member.remarks && ` - ${member.remarks}`}
                </p>
              </div>
            </div>
          </div>

	
	      <div className="flex flex-col sm:flex-row sm:space-x-6">
            {/* Scheme Number */}
            <div className="flex-1 flex items-start mb-4 sm:mb-0">
              <div className="mt-0.5 mr-3 text-blue-600">
                <Receipt size={18} />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Scheme Number</p>
                <p
                  className={`text-base font-medium ${
                    isAlreadyCollected ? 'text-red-600' : 'text-gray-800'
                  }`}
                >
                  {member.receipt || 'Not available'}
                </p>
              </div>
            </div>
          
            {/* Area */}
            <div className="flex-1 flex items-start">
              <div className="mt-0.5 mr-3 text-blue-600">
                <Receipt size={18} />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Area</p>
                 <p className="text-base font-medium text-gray-800">
                  {member.location}
                </p>
              </div>
            </div>
          </div>

	
	         <div className="mt-4">
              <p className="text-sm font-medium text-gray-500 mb-1">ID Card Distributed ?</p>
              <div className="flex items-center">
                <div className="mt-0.5 mr-3 text-blue-600">
                  <Receipt size={18} />
                </div>
                <div
                  className={`flex items-center px-3 py-2 rounded-md ${
                    member.carddistributedyes === 'Yes'
                      ? 'bg-green-100 text-green-800'
                      : 'bg-pink-100 text-pink-800'
                  }`}
                >
                  {member.carddistributedyes === 'Yes' ? (
                    <CheckCircle className="mr-2 text-green-600" />
                  ) : (
                    <XCircle className="mr-2 text-pink-600" />
                  )}
                  <span className="text-base font-medium">
                    {member.carddistributedyes} - {member.carddistributedname}
                  </span>
            
                  {/* Place button inline if "No" */}
                  {member.carddistributedyes === 'No' && (
                    <button
                      onClick={handleSaveID}
                      className="ml-4 px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      Distribute Card
                    </button>
                  )}
                </div>
              </div>
            </div>


	
	
	        
	        
	        {  /*<div className="flex items-start">
	                <div className="mt-0.5 mr-3 text-blue-600">
	                  <MessageSquare size={18} />
	                </div>
	                <div>
	                  <p className="text-sm font-medium text-gray-500">Previous Remarks</p>
	                  <p className="text-base font-medium text-gray-800">{member.remarks}</p>
	                </div>
	              </div>
	          */}
	
	        
	        <style>
	                  {`
	                    @keyframes blink {
	                      0%, 100% { opacity: 1; }
	                      50% { opacity: 0; }
	                    }
	                    .blink {
	                      animation: blink 1s step-start infinite;
	                    }
	                  `}
	                </style>
	                
	                {isPending && (
	                  <>
	                    {member.pending2024 && (
	                      <div className="flex items-start">
	                        <div className="mt-0.5 mr-3 text-red-600">
	                          <UserCheck size={18} />
	                        </div>
	                        <div>
	                          <p className="text-sm font-bold text-red-600 blink">Pending Status</p>
	                          <p className="text-base font-bold text-red-700 blink">{member.pending2024}</p>
	                        </div>
	                      </div>
	                    )}
	                  </>
	                )}
	        
	
	
	
	
	        
	        {isAlreadyCollected && (
	          <>
	            {member.collectedBy && (
	              <div className="flex items-start">
	                <div className="mt-0.5 mr-3 text-blue-600">
	                  <UserCheck size={18} />
	                </div>
	                <div>
	                  <p className="text-sm font-medium text-gray-500">Approved By</p>
	                  <p className="text-base font-medium text-gray-800">{member.collectedBy}</p>
	                </div>
	              </div>
	            )}
	            
	            {member.collectedTime && (
	              <div className="flex items-start">
	                <div className="mt-0.5 mr-3 text-blue-600">
	                  <Clock size={18} />
	                </div>
	                <div>
	                  <p className="text-sm font-medium text-gray-500">Approved Time</p>
	                  <p className="text-base font-medium text-gray-800">{member.collectedTime}</p>
	                </div>
	              </div>
	            )}

	
	            {member.remarks && (
	              <div className="flex items-start">
	                <div className="mt-0.5 mr-3 text-blue-600">
	                  <MessageSquare size={18} />
	                </div>
	                <div>
	                  <p className="text-sm font-medium text-gray-500">Previous Remarks</p>
	                  <p className="text-base font-medium text-gray-800">{member.remarks}</p>
	                </div>
	              </div>
	            )}
	          </>
	        )}
	
	         
	
	        {/*    
	        <div className="mt-6">
	          <label htmlFor="remarks" className="block text-sm font-medium text-gray-700 mb-2">
	            Remarks
	          </label>
	          <textarea
	            id="remarks"
	            rows={3}
	            value={remarks}
	            onChange={(e) => setRemarks(e.target.value)}
	            disabled={isAlreadyCollected}
	            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors disabled:bg-gray-100 disabled:cursor-not-allowed"
	            placeholder={isAlreadyCollected ? "Already approved" : "Enter any remarks..."}
	          />
	        </div>
	*/}
	
	
	        <div className="mt-6">
	  <label htmlFor="remarks" className="block text-sm font-medium text-gray-700 mb-2">
	    Remarks
	  </label>
	  <textarea
	    id="remarks"
	    rows={3}
	    value={remarks}
	    onChange={(e) => {
	      const sanitized = e.target.value.replace(/[^a-zA-Z0-9\s]/g, ''); // Remove special characters
	      setRemarks(sanitized);
	    }}
	    disabled={isAlreadyCollected}
	    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors disabled:bg-gray-100 disabled:cursor-not-allowed"
	    placeholder={isAlreadyCollected ? "Already approved" : "Enter any remarks..."}
	  />
	
	     
	          
	</div>
	
	        
	        {/* New Mobile Number */}
	       {/* <div className="mt-4">
	          <label htmlFor="newMobile" className="block text-sm font-medium text-gray-700 mb-2">New Mobile Number</label>
	          <input
	            id="newMobile"
	            type="tel"
	            value={newMobile}
	            onChange={(e) => setNewMobile(e.target.value)}
	            disabled={isAlreadyCollected}
	            placeholder="Enter new mobile number"
	            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors disabled:bg-gray-100 disabled:cursor-not-allowed"
	          />
	        </div>
	        */}
	        
	
	        {saveError && (
	          <div className="text-red-600 text-sm mt-2 bg-red-50 p-3 rounded-md border border-red-200">
	            {saveError}
	          </div>
	        )}
	
	        {saveSuccess && (
	          <div className="text-green-600 text-sm mt-2 bg-green-50 p-3 rounded-md border border-green-200">
	            Verification record saved successfully!
	          </div>
	        )}
	
	        <button
	          onClick={handleSave}
	          //disabled={isSaving || isAlreadyCollected}
	          disabled={isSaving || isAlreadyCollected || isCancelled}
	
	          className="w-full mt-4 bg-green-600 hover:bg-green-700 text-white font-medium py-2.5 px-4 rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center"
	        >
	          {isSaving ? (
	            <span className="flex items-center justify-center">
	              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
	                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
	                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
	              </svg>
	              Saving...
	            </span>
	          ) : (
	            <span className="flex items-center">
	              <Save size={18} className="mr-2" />
	              {/*{isAlreadyCollected ? 'Already Collected' : 'Collect'}
	              {isCancelled ? 'Cancelled - Contact Security Wing' : 'Collect'}*/}
	
	              {isCancelled
	                  ? 'Cancelled - Contact Security Wing'
	                  : isAlreadyCollected
	                    ? 'Already Approved'
	                    : 'Approve'}
	
	            </span>
	          )}
	        </button>
	
	
	           
	      </div>
	
	      {isAlreadyCollected && <ReceiptComponent member={member} />}
	    </div>
	  );
	};
	
	export default MemberProfile;