import React from 'react';
import html2canvas from 'html2canvas';
import { Download } from 'lucide-react';
import { KmccMember } from '../types';

interface ReceiptProps {
  member: KmccMember;
}

const Receipt: React.FC<ReceiptProps> = ({ member }) => {
  const downloadReceipt = async () => {
    const receiptElement = document.getElementById('receipt');
    if (!receiptElement) return;

    try {
      const canvas = await html2canvas(receiptElement, {
        scale: 2,
        backgroundColor: '#ffffff',
        logging: false,
        useCORS: true,
        allowTaint: true,
        width: 672, // 7 inches * 96 DPI
        height: 528  // 5.5 inches * 96 DPI
      });

      const link = document.createElement('a');
      link.download = `kmcc-receipt-${member.kmccId}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch (error) {
      console.error('Error generating receipt:', error);
    }
  };

  return (
    <div className="mt-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-gray-800">Payment Receipt</h3>
        <button
          onClick={downloadReceipt}
          className="flex items-center px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          <Download size={16} className="mr-2" />
          Download Receipt
        </button>
      </div>
      
      <div
        id="receipt"
        className="relative bg-white mx-auto"
        style={{
          width: '672px', // 7 inches * 96 DPI
          height: '528px', // 5.5 inches * 96 DPI
          padding: '40px',
          border: '12px double #1e40af',
          borderRadius: '12px',
          boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
          backgroundImage: 'linear-gradient(135deg, rgba(30, 64, 175, 0.05) 0%, rgba(30, 64, 175, 0.02) 100%)'
        }}
      >
        {/* Watermark */}
        <div 
          className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-25"
          style={{ zIndex: 0 }}
        >
          <img
            src="https://lh3.googleusercontent.com/d/1uSZG-9qjWQCOs6DfY-YjNmBsDyrtEILc"
            alt=""
            className="w-72 h-72 object-contain"
            crossOrigin="anonymous"
          />
        </div>

        {/* Header Section */}
        <div className="relative flex justify-between items-start mb-8" style={{ zIndex: 1 }}>
          <img
            src="https://lh3.googleusercontent.com/d/1uSZG-9qjWQCOs6DfY-YjNmBsDyrtEILc"
            alt="KMCC Logo"
            className="h-24 w-auto"
            crossOrigin="anonymous"
          />
          
          <div className="text-right">
            <h2 className="text-2xl font-bold text-blue-800 mb-2">
              Social Security Scheme 2025
            </h2>
            <div className="h-0.5 bg-blue-800 w-full mb-2"></div>
            <p className="text-xl font-semibold text-blue-700">Cash Receipt</p>
          </div>
        </div>

        {/* Receipt Number */}
        <div className="relative text-center mb-8" style={{ zIndex: 1 }}>
          <div className="inline-block border-2 border-blue-800 rounded-lg px-6 py-2 bg-blue-50">
            <span className="font-bold text-blue-800">Receipt No: </span>
            <span className="font-bold text-blue-900 text-xl">{member.receipt}</span>
          </div>
        </div>

        {/* Details Grid */}
        <div className="relative grid grid-cols-2 gap-x-8 gap-y-4" style={{ zIndex: 1 }}>
          {/* Left Column */}
          <div className="space-y-4">
            <div className="flex justify-between border-b border-blue-100 pb-1">
              <span className="font-medium text-gray-700">KMCC ID:</span>
              <span className="font-bold text-gray-900">{member.kmccId}</span>
            </div>
            
            <div className="flex justify-between border-b border-blue-100 pb-1">
              <span className="font-medium text-gray-700">Name:</span>
              <span className="font-bold text-gray-900">{member.name}</span>
            </div>
            
            <div className="flex justify-between border-b border-blue-100 pb-1">
              <span className="font-medium text-gray-700">Civil ID:</span>
              <span className="font-bold text-gray-900">{member.civilId}</span>
            </div>
            
            <div className="flex justify-between border-b border-blue-100 pb-1">
              <span className="font-medium text-gray-700">Mobile:</span>
              <span className="font-bold text-gray-900">{member.mobile}</span>
            </div>
            
            <div className="flex justify-between border-b border-blue-100 pb-1">
              <span className="font-medium text-gray-700">Amount:</span>
              <span className="font-bold text-green-700">3 Kuwaiti Dinar</span>
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-4">
            <div className="flex justify-between border-b border-blue-100 pb-1">
              <span className="font-medium text-gray-700">District:</span>
              <span className="font-bold text-gray-900">{member.district}</span>
            </div>
            
            <div className="flex justify-between border-b border-blue-100 pb-1">
              <span className="font-medium text-gray-700">Constituency:</span>
              <span className="font-bold text-gray-900">{member.constituency}</span>
            </div>
            
            <div className="flex justify-between border-b border-blue-100 pb-1">
              <span className="font-medium text-gray-700">Collected By:</span>
              <span className="font-bold text-gray-900">{member.collectedBy}</span>
            </div>
            
            <div className="flex justify-between border-b border-blue-100 pb-1">
              <span className="font-medium text-gray-700">Collection Time:</span>
              <span className="font-bold text-gray-900">{member.collectedTime}</span>
            </div>
          </div>

          {/* Remarks - Full Width */}
          {member.remarks && (
            <div className="col-span-2 border-b border-blue-100 pb-1">
              <span className="font-medium text-gray-700">Remarks:</span>
              <span className="font-bold text-gray-900 ml-2">{member.remarks}</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="relative mt-8 text-center" style={{ zIndex: 1 }}>
          <p className="text-xl font-semibold text-blue-800 mb-2" style={{ fontFamily: 'Arial, sans-serif' }}>
            جَزَاكَ اللهُ خَيْرًا عَلَى إِرْسَالِ الْمَالِ
          </p>
          <div className="w-40 h-0.5 bg-blue-800 mx-auto mb-3"></div>
          <p className="text-base font-medium text-gray-800">KMCC State Committee - Kuwait</p>
        </div>
      </div>
    </div>
  );
};

export default Receipt;