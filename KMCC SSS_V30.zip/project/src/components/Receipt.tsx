import React from 'react';
import html2canvas from 'html2canvas';
import { Download } from 'lucide-react';
import { KmccMember } from '../types';

interface ReceiptProps {
    member: KmccMember;
}

const Receipt: React.FC<ReceiptProps> = ({ member }) => {
    const downloadReceipt = async () => {
        const receiptElement = document.getElementById('receipt');
        if (!receiptElement) return;

        try {
            const canvas = await html2canvas(receiptElement, {
                scale: 2,
                backgroundColor: '#ffffff',
                logging: false,
                useCORS: true,
                allowTaint: true,
                width: 768, // 8 inches * 96 DPI
                height: 480  // 5 inches * 96 DPI
            });

            const link = document.createElement('a');
            link.download = `kmcc-receipt-${member.kmccId}.png`;
            link.href = canvas.toDataURL('image/png');
            link.click();
        } catch (error) {
            console.error('Error generating receipt:', error);
        }
    };

    return (
        <div className="mt-6">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-gray-800">Security Scheme Slip</h3>
                <button
                    onClick={downloadReceipt}
                    className="flex items-center px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                >
                    <Download size={16} className="mr-2" />
                    Download Slip
                </button>
            </div>

            <div
                id="receipt"
                className="relative bg-white mx-auto"
                style={{
                    width: '768px', // 8 inches * 96 DPI
                    height: '480px', // 5 inches * 96 DPI
                    padding: '24px',
                    border: '8px double #1e40af',
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
                    backgroundImage: 'linear-gradient(135deg, rgba(30, 64, 175, 0.05) 0%, rgba(30, 64, 175, 0.02) 100%)'
                }}
            >
                {/* Watermark */}
                <div
                    className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20"
                    style={{ zIndex: 0 }}
                >
                    <img
                        src="https://lh3.googleusercontent.com/d/1uSZG-9qjWQCOs6DfY-YjNmBsDyrtEILc"
                        alt=""
                        className="w-48 h-48 object-contain"
                        crossOrigin="anonymous"
                    />
                </div>

                {/* Header Section */}
                <div className="relative flex items-center justify-between mb-4" style={{ zIndex: 1 }}>
                    <img
                        src="https://lh3.googleusercontent.com/d/1uSZG-9qjWQCOs6DfY-YjNmBsDyrtEILc"
                        alt="KMCC Logo"
                        className="h-32 w-auto"
                        crossOrigin="anonymous"
                    />

                    <div className="text-right">
                        <h1 className="text-4xl font-bold text-blue-800 mb-1">
                            Social Security Scheme 2025
                        </h1>
                      {/*<p className="text-lg font-semibold text-blue-700">Receipt</p>*/}
                    </div>
                </div>

                {/* Receipt Number */}
                <div className="relative text-center -mt-8 mb-0" style={{ zIndex: 1 }}>
                    <div className="inline-block border-2 border-blue-800 rounded-lg px-4 py-1 bg-blue-50">
                        <span className="font-bold text-blue-800">Slip No: </span>
                        <span className="font-bold text-blue-900 text-lg">{member.receipt}</span>
                    </div>
                </div>



                {/* Details Section */}
                <div className="relative space-y-3" style={{ zIndex: 1 }}>
                    {/* Row 1 */}
                    <div className="grid grid-cols-2 gap-6">
                        <div className="border-b border-blue-100 pb-1">
                            <span className="font-medium text-gray-700">KMCC ID:</span>
                            <span className="float-right font-bold text-gray-900">{member.kmccId}</span>
                        </div>
                        <div className="border-b border-blue-100 pb-1">
                            <span className="font-medium text-gray-700">Name:</span>
                            <span className="float-right font-bold text-gray-900">{member.name}</span>
                        </div>
                    </div>

                    {/* Row 2 */}
                    <div className="grid grid-cols-2 gap-6">
                        <div className="border-b border-blue-100 pb-1">
                            <span className="font-medium text-gray-700">District:</span>
                            <span className="float-right font-bold text-gray-900">{member.district}</span>
                        </div>
                        <div className="border-b border-blue-100 pb-1">
                            <span className="font-medium text-gray-700">Constituency:</span>
                            <span className="float-right font-bold text-gray-900">{member.constituency}</span>
                        </div>
                    </div>

                    {/* Row 3 */}
                    <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                        <div className="border-b border-blue-100 pb-0.5">
                            <span className="font-medium text-gray-700">Civil ID:</span>
                            <span className="float-right font-bold text-gray-900">{member.civilId}</span>
                        </div>
                        <div className="border-b border-blue-100 pb-0.5">
                            <span className="font-medium text-gray-700">Mobile:</span>
                            <span className="float-right font-bold text-gray-900">{member.mobile}</span>
                        </div>
                    </div>

                    {/* Row 4 */}
                    <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                        <div className="border-b border-blue-100 pb-0.2">
                            <span className="font-medium text-gray-700">Approved By:</span>
                          {/*<span className="float-right font-bold text-gray-900">{member.collectedBy}</span>*/}
                          <span className="float-right font-bold text-gray-900">
                            {/* {member.collectedBy?.charAt(0).toUpperCase() + member.collectedBy?.slice(1).toLowerCase()} */}
                            {member.collectedBy &&
                                  `${member.collectedBy.charAt(0).toUpperCase()}${member.collectedBy.slice(1).toLowerCase()} (${member.collectedmobile})`}
                          </span>

                        </div>
                        <div className="border-b border-blue-100 pb-0.2">
                            <span className="font-medium text-gray-700">Approved Time:</span>
                            <span className="float-right font-bold text-gray-900">{member.collectedTime}</span>
                        </div>
                    </div>


                    <div className="border-b border-blue-100 pb-0.2 text-center">
                        <span className="font-bold italic text-red-600"
                            style={{ fontFamily: '"Arial Narrow", Arial, sans-serif' }} >
                            You have successfully completed the KMCC Social Security Scheme for the Year 2025
                        </span>
                    </div>



                    {/* Row 5 - Remarks */}
                    {member.remarks && (
                        <div className="border-b border-blue-100 mb-0.2">
                            <span className="font-medium text-gray-700">Remarks:</span>
                            <span className="ml-2 font-bold text-gray-900">{member.remarks}</span>
                        </div>
                    )}

                    {/* Footer */}
                    <div className="relative mt-6 text-center" style={{ zIndex: 1 }}>
                        <p className="text-lg font-semibold text-blue-800 mb-0" style={{ fontFamily: 'Arial, sans-serif' }}>
                            جَزَاكَ اللهُ خَيْرًا
                        </p>
                      {/*<div className="w-32 h-0.5 bg-blue-800 mx-auto mb-0"></div>   unde line */}
                        <p className="text-sm font-medium text-gray-800">KMCC State Committee - Kuwait</p>
                    </div>
                </div>
            </div>

        </div>
    );
};

export default Receipt;