import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  CreditCard, 
  XCircle, 
  LogOut, 
  Menu, 
  X, 
  PieChart,
  Receipt,
  Building,
  Clock,
  Globe,
  MapPin,
  Phone
} from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navigation: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { logout, authState } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  //const isAdminOrState = authState.user?.type === 'State/Admin' || authState.user?.type === 'Admin' || authState.user?.type === 'State';
  /*const isAdminOrState = authState.user?.type === 'State/Admin/District' || authState.user?.type === 'Admin' || authState.user?.type === 'State' || authState.user?.type === 'District';
  const isDistrict = authState.user?.type === 'District' || authState.user?.type === 'District';
  
  const menuItems = [
    { path: '/payment', label: 'Payment Collection', icon: CreditCard },
    ...(isAdminOrState ? [{
      label: 'Reports',
      icon: Receipt,
      submenu: [
        { path: '/dashboard', label: 'Member Status', icon: PieChart },
        { path: '/collection-details', label: 'Collection Details-District', icon: Building },
        { path: '/collection-details-constituency', label: 'Collection Details-Constituency', icon: MapPin },
        { path: '/district-receive', label: 'District Receive', icon: Building },
        { path: '/state-receive', label: 'State Receive', icon: Globe },
        { path: '/constituency-pending', label: 'Constituency Pending', icon: Clock },
        { path: '/cancellations', label: 'Cancellation List', icon: XCircle },
      ]
    }] : [])
  ];*/

  /*
const isAdmin = authState.user?.type === 'Admin';
const isState = authState.user?.type === 'State';
const isDistrict = authState.user?.type === 'District';
const isST = authState.user?.type === 'ST';

const isAdminOrState = isAdmin || isState || isST;

// Define submenu items
const allReportsSubmenu = [
  { path: '/dashboard', label: 'Member Status', icon: PieChart },
  { path: '/collection-details', label: 'Collection Details-District', icon: Building },
  { path: '/collection-details-constituency', label: 'Collection Details-Constituency', icon: MapPin },
  { path: '/district-receive', label: 'District Receive', icon: Building },
  { path: '/state-receive', label: 'State Receive', icon: Globe },
  { path: '/constituency-pending', label: 'Constituency Pending', icon: Clock },
  { path: '/cancellations', label: 'Cancellation List', icon: XCircle },
];

const districtReportsSubmenu = [
  { path: '/district-receive', label: 'District Receive', icon: Building },
  { path: '/constituency-pending', label: 'Constituency Pending', icon: Clock },
];

const menuItems = [
  { path: '/payment', label: 'Payment Collection', icon: CreditCard },
  ...(isAdminOrState || isDistrict || isST
    ? [{
        label: 'Reports',
        icon: Receipt,
        submenu: isAdminOrState ? allReportsSubmenu : districtReportsSubmenu
      }]
    : [])
];
*/


const isAdmin = authState.user?.type === 'Admin';
const isState = authState.user?.type === 'State';
const isDistrict = authState.user?.type === 'District';
const isST = authState.user?.type === 'ST';
const isConstituency = authState.user?.type === 'Constituency';
const isCardDistribute = authState.user?.type === 'IDCard';

let reportsSubmenu = [];

if (isAdmin) {
  // Admin gets all menu items
  reportsSubmenu = [
    { path: '/dashboard', label: 'Member Status', icon: PieChart },
    { path: '/Card_Distribute', label: 'Card Distribution', icon: XCircle },
    { path: '/collection-details', label: 'Collection Details-District', icon: Building },
    { path: '/collection-details-constituency', label: 'Collection Details-Constituency', icon: MapPin },
    { path: '/district-receive', label: 'District Receive', icon: Building },
    { path: '/state-receive', label: 'State Receive', icon: Globe },
    { path: '/constituency-pending', label: 'Constituency Pending', icon: Clock },
    { path: '/constituency-full', label: 'Constituency Full List', icon: Clock },
    { path: '/constituency-collected', label: 'Constituency Collected Only', icon: Clock },
    { path: '/collected-byme', label: 'Constituency Approved by Me', icon: Clock },
    { path: '/distcollected-byme', label: 'District Approved by Me', icon: Clock },
    { path: '/stcollected-byme', label: 'State Approved by Me', icon: Clock },
    { path: '/cancellations', label: 'Cancellation List', icon: XCircle },
    { path: '/Constituency_Graph', label: 'Constituency Graph', icon: XCircle },
    { path: '/ConstituencyCollected', label: 'Constituency Collected By', icon: XCircle },
    { path: '/Change_Mobile', label: 'Mobile Number Change Request', icon: XCircle },
    { path: '/Change_Location', label: 'Location Change Request', icon: XCircle },
    { path: '/Change_Master', label: 'Change Master Data', icon: XCircle },
    { path: '/ContactUs_Page', label: 'Contact Us', icon: XCircle },
    { path: '/congrats_Page', label: 'Congrats', icon: XCircle },
    { path: '/Card_Distribute', label: 'Card Distribution', icon: XCircle },
  ];
  
} else if (isState) {
  // State users get all except two items
  reportsSubmenu = [
    { path: '/dashboard', label: 'Member Status', icon: PieChart },
    { path: '/Card_Distribute', label: 'Card Distribution', icon: XCircle },
    { path: '/collection-details', label: 'Collection Details-District', icon: Building },
    { path: '/collection-details-constituency', label: 'Collection Details-Constituency', icon: MapPin },
    { path: '/constituency-pending', label: 'Constituency Pending', icon: Clock },
    { path: '/constituency-full', label: 'Constituency Full List', icon: Clock },
    { path: '/constituency-collected', label: 'Constituency Collected Only', icon: Clock },
    { path: '/collected-byme', label: 'Constituency Approved by Me', icon: Clock },
    { path: '/stcollected-byme', label: 'State Approved by Me', icon: Clock },
    { path: '/cancellations', label: 'Cancellation List', icon: XCircle },
    //{ path: '/ConstituencyCollected', label: 'Constituency Collected By', icon: XCircle },
    { path: '/Change_Mobile', label: 'Mobile Number Change Request', icon: XCircle },
    { path: '/Change_Location', label: 'Location Change Request', icon: XCircle },
    { path: '/ContactUs_Page', label: 'Contact Us', icon: XCircle },
  ];
} else if (isCardDistribute) {

  reportsSubmenu = [
    { path: '/Card_Distribute', label: 'Card Distribution', icon: XCircle },
  ];
}
  else if (isConstituency) {
  reportsSubmenu = [
    { path: '/Card_Distribute', label: 'Card Distribution', icon: XCircle },
    { path: '/constituency-pending', label: 'Constituency Pending', icon: Clock },
    { path: '/constituency-full', label: 'Constituency Full List', icon: Clock },
    { path: '/collected-byme', label: 'Constituency Approved by Me', icon: Clock },
    { path: '/Constituency_Graph', label: 'Constituency Graph', icon: XCircle },
    { path: '/ConstituencyCollected', label: 'Constituency Collected By', icon: XCircle },
    { path: '/constituency-collected', label: 'Constituency Collected Only', icon: Clock },
    { path: '/Change_Mobile', label: 'Mobile Number Change Request', icon: XCircle },
    { path: '/Change_Location', label: 'Location Change Request', icon: XCircle },
    { path: '/ContactUs_Page', label: 'Contact Us', icon: XCircle },
  ];
}
  else if (isST) {
  // ST users get all except one item
  reportsSubmenu = [
    { path: '/dashboard', label: 'Member Status', icon: PieChart },
    { path: '/Card_Distribute', label: 'Card Distribution', icon: XCircle },
    { path: '/collection-details', label: 'Collection Details-District', icon: Building },
    { path: '/collection-details-constituency', label: 'Collection Details-Constituency', icon: MapPin },
    { path: '/state-receive', label: 'State Receive', icon: Globe },
    { path: '/constituency-pending', label: 'Constituency Pending', icon: Clock },
    { path: '/constituency-full', label: 'Constituency Full List', icon: Clock },
    { path: '/constituency-collected', label: 'Constituency Collected Only', icon: Clock },
    { path: '/collected-byme', label: 'Constituency Approved by Me', icon: Clock },
    { path: '/distcollected-byme', label: 'District Approved by Me', icon: Clock },
    { path: '/stcollected-byme', label: 'State Approved by Me', icon: Clock },
    { path: '/cancellations', label: 'Cancellation List', icon: XCircle },
    //{ path: '/ConstituencyCollected', label: 'Constituency Collected By', icon: XCircle },
    { path: '/Change_Mobile', label: 'Mobile Number Change Request', icon: XCircle },
    { path: '/Change_Location', label: 'Location Change Request', icon: XCircle },
    { path: '/ContactUs_Page', label: 'Contact Us', icon: XCircle },
  ];
}

  const districtReportsSubmenu = [
  { path: '/district-receive', label: 'District Receive', icon: Building },
    { path: '/collection-details-constituency', label: 'Collection Details-Constituency', icon: MapPin },
    { path: '/constituency-pending', label: 'Constituency Pending', icon: Clock },
    { path: '/constituency-full', label: 'Constituency Full List', icon: Clock },
    { path: '/constituency-collected', label: 'Constituency Collected Only', icon: Clock },
    { path: '/collected-byme', label: 'Approved by Me', icon: Clock },
    { path: '/Constituency_Graph', label: 'Constituency Graph', icon: XCircle },
    { path: '/ConstituencyCollected', label: 'Constituency Collected By', icon: XCircle },
    { path: '/Change_Mobile', label: 'Mobile Number Change Request', icon: XCircle },
    { path: '/Change_Location', label: 'Location Change Request', icon: XCircle },
    { path: '/ContactUs_Page', label: 'Contact Us', icon: XCircle },
];
  
  {/*
   else if (isDistrict) {
        //const districtReportsSubmenu = [
      reportsSubmenu = [
            { path: '/district-receive', label: 'District Receive', icon: Building },
            { path: '/collection-details-constituency', label: 'Collection Details-Constituency', icon: MapPin },
            { path: '/constituency-pending', label: 'Constituency Pending', icon: Clock },
            { path: '/constituency-full', label: 'Constituency Full List', icon: Clock },
            { path: '/constituency-collected', label: 'Constituency Collected Only', icon: Clock },
            { path: '/collected-byme', label: 'Constituency Approved by Me', icon: Clock },
            { path: '/distcollected-byme', label: 'District Approved by Me', icon: Clock },
            { path: '/Constituency_Graph', label: 'Constituency Graph', icon: XCircle },
            { path: '/ConstituencyCollected', label: 'Constituency Collected By', icon: XCircle },
            { path: '/Change_Mobile', label: 'Mobile Number Change Request', icon: XCircle },
            { path: '/Change_Location', label: 'Location Change Request', icon: XCircle },
            { path: '/ContactUs_Page', label: 'Contact Us', icon: XCircle },
        ];
   }
  */}

  
  
const menuItems = [
  { path: '/payment', label: 'Security  Scheme Accept', icon: CreditCard },
  ...((isAdmin || isState || isST || isDistrict || isConstituency)
    ? [{
        label: 'Reports',
        icon: Receipt,
        submenu: isAdmin || isState || isST || isConstituency ? reportsSubmenu : districtReportsSubmenu
      }]
    : []),
    //{ path: '/change-mobile', label: 'Change Mobile Number', icon: Phone },
    { path: '/ContactUs_Page', label: 'Contact Us', icon: XCircle },
];


  {/*
 const menuItems = [
   // Conditionally include the Card Distribution or Contact Us menu item
  ...(isCardDistribute
    ? [
        {
          path: '/Card_Distribute',
          label: 'Card Distribution',
          icon: XCircle,
        },
      ]
    : [
        {
          path: '/ContactUs_Page',
          label: 'Contact Us',
          icon: XCircle,
        },
      ]),
   
  // Add payment + reports if user has any of those roles
  ...(isAdmin || isState || isST || isDistrict || isConstituency
    ? [
        { path: '/payment', label: 'Security Scheme Accept', icon: CreditCard },
        {
          label: 'Reports',
          icon: Receipt,
          submenu: (isAdmin || isState || isST || isConstituency)
            ? reportsSubmenu
            : districtReportsSubmenu,
            //: reportsSubmenu,
        },
      ]
    : []),  
];
*/}


  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handleMenuClick = (path: string) => {
    navigate(path);
    setIsMenuOpen(false);
  };

  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4">
        <div className="relative flex items-center justify-between h-16">
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          <div className="hidden md:flex md:space-x-8">
            {menuItems.map((item, index) => {
              const Icon = item.icon;
              if (item.submenu) {
                return (
                  <div key={index} className="relative group">
                    <button className="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 hover:text-gray-700 hover:border-gray-300">
                      <Icon size={18} className="mr-2" />
                      {item.label}
                    </button>
                    <div className="absolute left-0 mt-2 w-72 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                      <div className="py-1" role="menu">
                        {item.submenu.map((subItem) => {
                          const SubIcon = subItem.icon;
                          return (
                            <button
                              key={subItem.path}
                              onClick={() => handleMenuClick(subItem.path)}
                              className={`w-full text-left px-4 py-2 text-sm flex items-center ${
                                location.pathname === subItem.path
                                  ? 'bg-gray-100 text-gray-900'
                                  : 'text-gray-700 hover:bg-gray-50'
                              }`}
                            >
                              <SubIcon size={16} className="mr-2" />
                              {subItem.label}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                );
              }
              return (
                <button
                  key={item.path}
                  onClick={() => handleMenuClick(item.path)}
                  className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                    location.pathname === item.path
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon size={18} className="mr-2" />
                  {item.label}
                </button>
              );
            })}
          </div>

          <button
            onClick={handleLogout}
            className="hidden md:inline-flex items-center px-3 py-2 text-sm font-medium text-red-600 hover:text-red-800"
          >
            <LogOut size={18} className="mr-2" />
            Logout
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden">
            <div className="pt-2 pb-3 space-y-1">
              {menuItems.map((item, index) => {
                const Icon = item.icon;
                if (item.submenu) {
                  return (
                    <div key={index} className="space-y-1">
                      <div className="px-3 py-2 text-base font-medium text-gray-600">
                        <Icon size={20} className="inline-block mr-2" />
                        {item.label}
                      </div>
                      <div className="pl-6 space-y-1">
                        {item.submenu.map((subItem) => {
                          const SubIcon = subItem.icon;
                          return (
                            <button
                              key={subItem.path}
                              onClick={() => handleMenuClick(subItem.path)}
                              className={`w-full flex items-center px-3 py-2 text-base font-medium rounded-md ${
                                location.pathname === subItem.path
                                  ? 'bg-blue-50 text-blue-600'
                                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                              }`}
                            >
                              <SubIcon size={18} className="mr-2" />
                              {subItem.label}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                }
                return (
                  <button
                    key={item.path}
                    onClick={() => handleMenuClick(item.path)}
                    className={`w-full flex items-center px-3 py-2 text-base font-medium rounded-md ${
                      location.pathname === item.path
                        ? 'bg-blue-50 text-blue-600'
                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                    }`}
                  >
                    <Icon size={20} className="mr-3" />
                    {item.label}
                  </button>
                );
              })}
              <button
                onClick={handleLogout}
                className="w-full flex items-center px-3 py-2 text-base font-medium text-red-600 hover:bg-red-50 hover:text-red-700 rounded-md"
              >
                <LogOut size={20} className="mr-3" />
                Logout
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navigation;