import React, { useState, useEffect, useRef } from 'react';
import { Filter, Download } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { getDistrictsAndConstituencies, getMemberStatusData } from '../utils/sheetsApi';
import html2canvas from 'html2canvas';

const CollectionDetailsPage: React.FC = () => {
  const [districts, setDistricts] = useState<string[]>([]);
  const [constituencies, setConstituencies] = useState<Record<string, string[]>>({});
  const [selectedDistrict, setSelectedDistrict] = useState<string>('All');
  const [selectedConstituency, setSelectedConstituency] = useState<string>('All');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string>('');
  const { authState } = useAuth();
  const isAdmin = authState.user?.type === 'Admin';
  const isState = authState.user?.type === 'State';
  const isST = authState.user?.type === 'ST';
  const userDistrict = authState.user?.district;
  const userConstituency = authState.user?.constituency;

  // ... rest of the state declarations

  useEffect(() => {
    const loadData = async () => {
      try {
        setIsLoading(true);
        const [{ districts: districtList, constituencies: constituencyMap }, memberStatusData] = await Promise.all([
          getDistrictsAndConstituencies(),
          getMemberStatusData(selectedDistrict, selectedConstituency)
        ]);
        
        if (!isAdmin && !isState && !isST) {
          // Filter districts and constituencies based on user permissions
          const filteredDistricts = districtList.filter(d => d === 'All' || d === userDistrict);
          const filteredConstituencies = {
            [userDistrict]: constituencyMap[userDistrict]?.filter(c => 
              c === 'All' || c === userConstituency
            ) || ['All']
          };
          
          setDistricts(filteredDistricts);
          setConstituencies(filteredConstituencies);
          setSelectedDistrict(userDistrict || 'All');
          setSelectedConstituency(userConstituency || 'All');
        } else {
          setDistricts(districtList);
          setConstituencies(constituencyMap);
        }

        setDistrictSummary(memberStatusData.districtSummary);
        setStats(memberStatusData.squareReport);
      } catch (err) {
        setError('Failed to load data. Please try again later.');
        console.error('Error loading data:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [selectedDistrict, selectedConstituency, isAdmin, isState, userDistrict, userConstituency]);

  const handleDistrictChange = (district: string) => {
    setSelectedDistrict(district);
    if (!isAdmin && !isState) {
      setSelectedConstituency(userConstituency || 'All');
    } else {
      setSelectedConstituency('All');
    }
  };

  // ... rest of the component implementation remains the same

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* ... existing JSX ... */}
      
      <div className="mb-8 bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center mb-4">
          <Filter size={20} className="text-gray-500 mr-2" />
          <h2 className="text-lg font-semibold text-gray-700">Filters</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="district" className="block text-sm font-medium text-gray-700 mb-1">
              District
            </label>
            <select
              id="district"
              value={selectedDistrict}
              onChange={(e) => handleDistrictChange(e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors ${
                !isAdmin && !isState ? 'bg-gray-100' : ''
              }`}
              disabled={isLoading || (!isAdmin && !isState)}
            >
              {districts.map((district) => (
                <option key={district} value={district}>
                  {district}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="constituency" className="block text-sm font-medium text-gray-700 mb-1">
              Constituency
            </label>
            <select
              id="constituency"
              value={selectedConstituency}
              onChange={(e) => setSelectedConstituency(e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors ${
                !isAdmin && !isState ? 'bg-gray-100' : ''
              }`}
              disabled={isLoading || (!isAdmin && !isState)}
            >
              {constituencies[selectedDistrict]?.map((constituency) => (
                <option key={constituency} value={constituency}>
                  {constituency}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* ... rest of the JSX remains the same ... */}
    </div>
  );
};

export default CollectionDetailsPage;