import React from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Pie } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend);

interface StatusPieChartProps {
  active: number;
  cancelled: number;
  collected: number;
}

const StatusPieChart: React.FC<StatusPieChartProps> = ({ active, cancelled, collected }) => {
  const total = active + cancelled;
  const uncollected = active - collected;

  const data = {
    labels: ['Active (Uncollected)', 'Cancelled', 'Collected'],
    datasets: [
      {
        data: [uncollected, cancelled, collected],
        backgroundColor: [
          'rgba(234, 179, 8, 0.8)',   // yellow-500
          'rgba(239, 68, 68, 0.8)',   // red-500
          'rgba(34, 197, 94, 0.8)',   // green-500
        ],
        borderColor: [
          'rgba(234, 179, 8, 1)',
          'rgba(239, 68, 68, 1)',
          'rgba(34, 197, 94, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          font: {
            size: 14,
            family: 'Inter'
          },
          padding: 20
        }
      },
      tooltip: {
        callbacks: {
          label: (context: any) => {
            const label = context.label || '';
            const value = context.raw || 0;
            const percentage = ((value / total) * 100).toFixed(1);
            return `${label}: ${value} (${percentage}%)`;
          },
        },
      },
    },
  };

  return (
    <div className="w-full h-full flex items-center justify-center">
      <div className="w-full max-w-xs">
        <Pie data={data} options={options} />
      </div>
    </div>
  );
};

export default StatusPieChart;