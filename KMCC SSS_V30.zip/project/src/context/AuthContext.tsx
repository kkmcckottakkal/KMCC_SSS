import React, { createContext, useContext, useState, ReactNode } from 'react';
import { AuthState, User, KmccMember } from '../types';

interface AuthContextType {
  authState: AuthState;
  login: (user: User) => void;
  logout: () => void;
  setMember: (member: KmccMember | null) => void;
}

const initialState: AuthState = {
  isAuthenticated: false,
  user: null,
  member: null
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [authState, setAuthState] = useState<AuthState>(initialState);

  const login = (user: User) => {
    setAuthState({
      ...authState,
      isAuthenticated: true,
      user
    });
  };

  const logout = () => {
    setAuthState(initialState);
  };

  const setMember = (member: KmccMember | null) => {
    setAuthState({
      ...authState,
      member
    });
  };

  return (
    <AuthContext.Provider value={{ authState, login, logout, setMember }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};