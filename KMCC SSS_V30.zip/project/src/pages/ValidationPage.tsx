import React from 'react';
import KmccIdForm from '../components/KmccIdForm';
import MemberProfile from '../components/MemberProfile';

const ValidationPage: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col items-center bg-gradient-to-b from-blue-50 to-blue-100 px-4 py-8">
      <div className="w-full max-w-md text-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Security Scheme Validation</h1>
        
      </div>
      
      <div className="w-full max-w-md">
        <KmccIdForm />
        <MemberProfile />
      </div>
    </div>
  );
};

export default ValidationPage