import React, { useState, useEffect, useRef } from 'react';
import { Filter, TrendingUp, Users, PieChart as ChartPie, ArrowUpRight, Building, MapPin, Download } from 'lucide-react';
import { getDistrictsAndConstituencies, getMemberStatusData } from '../utils/sheetsApi';
import html2canvas from 'html2canvas';

const CollectionDetailsPage: React.FC = () => {
  const [districts, setDistricts] = useState<string[]>(['All']);
  const [constituencies, setConstituencies] = useState<Record<string, string[]>>({ 'All': ['All'] });
  const [selectedDistrict, setSelectedDistrict] = useState<string>('All');
  const [selectedConstituency, setSelectedConstituency] = useState<string>('All');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string>('');
  const statsRef = useRef<HTMLDivElement>(null);
  const tableRef = useRef<HTMLDivElement>(null);
  const combinedRef = useRef<HTMLDivElement>(null);
  const [stats, setStats] = useState({
    constituency: {
      totalReceived: 0,
      totalActive: 0,
      percentage: 0
    },
    district: {
      totalReceived: 0,
      totalActive: 0,
      totalReceivedByConstituency: 0,
      ratio: 0
    },
    state: {
      totalReceived: 0,
      totalActive: 0,
      totalReceivedByDistrict: 0,
      ratio: 0
    }
  });
  const [districtSummary, setDistrictSummary] = useState<Array<{
    district: string;
    totalActiveMembers: number;
    collectedByConstituency: number;
    collectedByDistrict: number;
    collectedByState: number;
  }>>([]);

  useEffect(() => {
    const loadData = async () => {
      try {
        setIsLoading(true);
        const [{ districts: districtList, constituencies: constituencyMap }, memberStatusData] = await Promise.all([
          getDistrictsAndConstituencies(),
          getMemberStatusData(selectedDistrict, selectedConstituency)
        ]);
        
        // Ensure 'All' options are included
        const updatedDistricts = ['All', ...districtList];
        const updatedConstituencies = {
          'All': ['All'],
          ...constituencyMap
        };
        
        setDistricts(updatedDistricts);
        setConstituencies(updatedConstituencies);
        setDistrictSummary(memberStatusData.districtSummary);
        setStats(memberStatusData.squareReport);
      } catch (err) {
        setError('Failed to load data. Please try again later....');
        console.error('Error loading data:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [selectedDistrict, selectedConstituency]);

  const handleDistrictChange = (district: string) => {
    setSelectedDistrict(district);
    setSelectedConstituency('All');
  };

  const downloadCombinedImage = async () => {
    if (!combinedRef.current) return;

    try {
      const canvas = await html2canvas(combinedRef.current, {
        scale: 2,
        backgroundColor: '#ffffff',
        logging: false,
        useCORS: true,
        allowTaint: true,
        width: 1080,
        windowWidth: 1080
      });

      const link = document.createElement('a');
      link.download = `collection-report-${new Date().toISOString().split('T')[0]}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch (error) {
      console.error('Error generating image:', error);
    }
  };

  const StatCard: React.FC<{ 
    title: string; 
    value: number;
    percentages?: { value: number; label: string }[];
    icon: React.ReactNode;
    color: string;
  }> = ({ title, value, percentages, icon, color }) => {
    return (
      <div className={`bg-white rounded-xl shadow-md p-6 border-l-4 ${color}`}>
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm text-gray-600 mb-1">{title}</p>
            <p className="text-2xl font-bold text-gray-900">
              {value.toLocaleString()}
            </p>
            {percentages && (
              <div className="mt-2 space-y-1">
                {percentages.map((p, i) => (
                  <p key={i} className="text-sm text-gray-500">
                    {p.label}: {p.value.toFixed(1)}%
                  </p>
                ))}
              </div>
            )}
          </div>
          <div className={`p-2 rounded-lg ${color.replace('border-', 'bg-').replace('-600', '-100')}`}>
            {icon}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Collection Overview</h1>
          <p className="mt-1 text-gray-600">
            {/*State-wide collection statistics and summary*/}
          </p>
        </div>
        <button
          onClick={downloadCombinedImage}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          <Download size={16} className="mr-2" />
          Download Report
        </button>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-red-700">{error}</p>
        </div>
      )}

      <div className="mb-8 bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center mb-4">
          <Filter size={20} className="text-gray-500 mr-2" />
          <h2 className="text-lg font-semibold text-gray-700">Filters</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="district" className="block text-sm font-medium text-gray-700 mb-1">
              District
            </label>
            <select
              id="district"
              value={selectedDistrict}
              onChange={(e) => handleDistrictChange(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
              disabled={isLoading}
            >
              {districts.map((district) => (
                <option key={district} value={district}>
                  {district}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="constituency" className="block text-sm font-medium text-gray-700 mb-1">
              Constituency
            </label>
            <select
              id="constituency"
              value={selectedConstituency}
              onChange={(e) => setSelectedConstituency(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
              disabled={isLoading}
            >
              {constituencies[selectedDistrict]?.map((constituency) => (
                <option key={constituency} value={constituency}>
                  {constituency}
                </option>
              )) || (
                <option value="All">All</option>
              )}
            </select>
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="h-64 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        </div>
      ) : (
        <div ref={combinedRef} className="bg-white p-6 rounded-lg space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <StatCard
              title="Total Active Members"
              value={stats.state.totalActive}
              icon={<Users className="h-6 w-6 text-blue-600" />}
              color="border-blue-600"
            />
            <StatCard
              title="Total Received by Constituency"
              value={stats.constituency.totalReceived}
              percentages={[
                { value: (stats.constituency.totalReceived / stats.state.totalActive) * 100, label: 'vs Active' }
              ]}
              icon={<MapPin className="h-6 w-6 text-orange-600" />}
              color="border-orange-600"
            />
            <StatCard
              title="Total Received by District"
              value={stats.district.totalReceived}
              percentages={[
                { value: (stats.district.totalReceived / stats.constituency.totalReceived) * 100, label: 'vs Constituency' },
                { value: (stats.district.totalReceived / stats.state.totalActive) * 100, label: 'vs Active' }
              ]}
              icon={<Building className="h-6 w-6 text-purple-600" />}
              color="border-purple-600"
            />
            <StatCard
              title="Total Received by State"
              value={stats.state.totalReceived}
              percentages={[
                { value: (stats.state.totalReceived / stats.district.totalReceived) * 100, label: 'vs District' },
                { value: (stats.state.totalReceived / stats.constituency.totalReceived) * 100, label: 'vs Constituency' },
                { value: (stats.state.totalReceived / stats.state.totalActive) * 100, label: 'vs Active' }
              ]}
              icon={<ChartPie className="h-6 w-6 text-green-600" />}
              color="border-green-600"
            />
          </div>

          <div className="overflow-hidden">
            <div className="px-4 py-3 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-700">District-wise Summary</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Sl. No
                    </th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      District
                    </th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Total Active
                    </th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      By Constituency
                    </th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      By District
                    </th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      By State
                    </th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Const Pending
                    </th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Dist Pending
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {districtSummary.map((item, index) => {
                    const isTotal = item.district === 'Total';
                    return (
                      <tr key={item.district} className={isTotal ? 'bg-gray-50 font-semibold' : ''}>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">
                          {!isTotal && index + 1}
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm font-medium text-gray-900">
                          {item.district}
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-right text-gray-900 font-medium">
                          {item.totalActiveMembers}
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-right text-blue-600 font-medium">
                          {item.collectedByConstituency}
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-right text-green-600 font-medium">
                          {item.collectedByDistrict}
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-right text-purple-600 font-medium">
                          {item.collectedByState}
                        </td>

                        <td className="px-4 py-2 whitespace-nowrap text-sm text-right text-green-600 font-medium">
                            {Number(item.collectedByConstituency) - Number(item.collectedByDistrict)}
                          </td>

                        <td className="px-4 py-2 whitespace-nowrap text-sm text-right text-green-600 font-medium">
                            {Number(item.collectedByDistrict) - Number(item.collectedByState)}
                          </td>

                        
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CollectionDetailsPage;