import React, { useState } from 'react';
import { Search, Save, Phone, User, MapPin, Building, CreditCard, CheckCircle, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { saveLocationChangeRecord } from '../utils/sheetsApi';

interface MemberData {
  kmccId: string;
  name: string;
  district: string;
  constituency: string;
  civilId: string;
  oldLocation: string;
}

const ChangeLocationPage1: React.FC = () => {
  const { authState } = useAuth();
  const [searchValue, setSearchValue] = useState('');
  const [memberData, setMemberData] = useState<MemberData | null>(null);
  const [newLocation, setnewLocation] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const validateMobile = (mobile: string): boolean => {
    //return /^\d{8}$/.test(mobile);
      return /^[a-zA-Z0-9 ]{3,}$/.test(mobile.trim());
  };

  const handleSearch = async () => {
    if (!searchValue.trim()) {
      setError('Please enter a KMCC ID or mobile number');
      return;
    }

    setIsSearching(true);
    setError('');
    setMemberData(null);
    setnewLocation('');

    try {
      const sheetId = '1Qp_PQ0WqkzweQoWhLoomDg8E2uM4foSVWS5UvoqTEyk';
      const response = await fetch(
        `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:csv&gid=805376514&timestamp=${Date.now()}`,
        { cache: 'no-store' }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch data');
      }

      const csvData = await response.text();
      const rows = csvData.split('\n').slice(1);

      const matchingRow = rows.find(row => {
        const columns = row.split(',').map(col => col.trim().replace(/^"|"$/g, ''));
        return columns[1]?.trim() === searchValue.trim() || // KMCC ID (Column 2)
               columns[6]?.trim() === searchValue.trim();   // Mobile (Column 7)
      });

      if (matchingRow) {
        const columns = matchingRow.split(',').map(col => col.trim().replace(/^"|"$/g, ''));
        setMemberData({
          kmccId: columns[1] || '',
          name: columns[2] || '',
          district: columns[3] || '',
          constituency: columns[4] || '',
          civilId: columns[5] || '',
          oldLocation: columns[7] || ''
        });
      } else {
        setError('No member found with the provided KMCC ID or mobile number');
      }
    } catch (err) {
      setError('Failed to search for member. Please try again.');
      console.error('Search error:', err);
    } finally {
      setIsSearching(false);
    }
  };

  const handleSave = async () => {
    if (!memberData || !newLocation.trim()) {
      setError('Please complete all required fields');
      return;
    }

    if (!validateMobile(newLocation)) {
      setError('New mobile number must be exactly 8 digits');
      return;
    }

    if (newLocation === memberData.oldLocation) {
      setError('New Location must be different from the current Location');
      return;
    }

    setIsSaving(true);
    setError('');
    setSuccess('');

    try {
      const record = {
        kmccId: memberData.kmccId,
        name: memberData.name,
        oldLocation: memberData.oldLocation,
        newLocation: newLocation,
        changedBy: authState.user?.id || '',
        changedDt: new Date().toLocaleString('en-US', { timeZone: 'Asia/Kuwait' })
      };

      await saveLocationChangeRecord(record);
      
      setSuccess('Location change request submitted successfully!');
      setMemberData(null);
      setSearchValue('');
      setnewLocation('');
      setTimeout(() => setSuccess(''), 5000);
    } catch (err) {
      setError('Failed to save mobile change request. Please try again.');
      console.error('Save error:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleClear = () => {
    setSearchValue('');
    setMemberData(null);
    setnewLocation('');
    setError('');
    setSuccess('');
  };

  const handlenewLocationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Allow only numeric characters and limit to 8 digits
//    if (/^\d*$/.test(value) && value.length <= 8) {
 //     setnewLocation(value);
 //     setError('');
  //  }

    setnewLocation(value);
  };

  const isFormValid = memberData && newLocation.trim() && validateMobile(newLocation) && newLocation !== memberData.oldLocation;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Change Member Location</h1>
        <p className="mt-1 text-gray-600">Update member Location information</p>
      </div>

      {/* Success Message */}
      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-md flex items-center">
          <CheckCircle size={20} className="text-green-600 mr-2" />
          <p className="text-green-700">{success}</p>
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md flex items-center">
          <AlertCircle size={20} className="text-red-600 mr-2" />
          <p className="text-red-700">{error}</p>
        </div>
      )}

      {/* Search Section */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-lg font-semibold text-gray-700 mb-4 flex items-center">
          <Search size={20} className="mr-2" />
          Search Member
        </h2>
        
        <div className="space-y-4">
          <div>
            <label htmlFor="search" className="block text-sm font-medium text-gray-700 mb-1">
              KMCC ID or Current Mobile Number
            </label>
            <div className="flex gap-3">
              {/* <input
                id="search"
                type="text"
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
                placeholder="Enter KMCC ID or mobile number"
                className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              /> */}
              <input
                  id="search"
                  type="text"
                  inputMode="numeric"
                  pattern="\d*"
                  autoComplete="off" // ⛔ disables browser suggestions/autofill
                  autoCorrect="off"  // ⛔ disables autocorrect on some mobile browsers
                  spellCheck="false" // ⛔ disables spell check
                  value={searchValue}
                  onChange={(e) => {
                    const numericOnly = e.target.value.replace(/\D/g, '');
                    setSearchValue(numericOnly);
                  }}
                  placeholder="Enter KMCC ID or mobile number"
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                />


              <button
                onClick={handleSearch}
                disabled={isSearching || !searchValue.trim()}
                className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
              >
                {isSearching ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                ) : (
                  <Search size={16} className="mr-2" />
                )}
                {isSearching ? 'Searching...' : 'Search'}
              </button>
              <button
                onClick={handleClear}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2"
              >
                Clear
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Member Details Section */}
      {memberData && (
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-lg font-semibold text-gray-700 mb-4 flex items-center">
            <User size={20} className="mr-2" />
            Member Information
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="mt-0.5 mr-3 text-blue-600">
                  <User size={18} />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">KMCC ID</p>
                  <p className="text-base font-medium text-gray-800">{memberData.kmccId}</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="mt-0.5 mr-3 text-blue-600">
                  <User size={18} />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Name</p>
                  <p className="text-base font-medium text-gray-800">{memberData.name}</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="mt-0.5 mr-3 text-blue-600">
                  <Phone size={18} />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Current Location</p>
                  <p className="text-base font-medium text-gray-800">{memberData.oldLocation}</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-start">
                <div className="mt-0.5 mr-3 text-blue-600">
                  <MapPin size={18} />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">District</p>
                  <p className="text-base font-medium text-gray-800">{memberData.district}</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="mt-0.5 mr-3 text-blue-600">
                  <Building size={18} />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Constituency</p>
                  <p className="text-base font-medium text-gray-800">{memberData.constituency}</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="mt-0.5 mr-3 text-blue-600">
                  <CreditCard size={18} />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Civil ID</p>
                  <p className="text-base font-medium text-gray-800">{memberData.civilId}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Update Section */}
      {memberData && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold text-gray-700 mb-4 flex items-center">
            <Phone size={20} className="mr-2" />
            Update Location
          </h2>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="newLocation" className="block text-sm font-medium text-gray-700 mb-1">
                New Location
              </label>
              {/* <input
                id="newLocation"
                type="tel"
                inputMode="numeric"
                pattern="\d*"
                value={newLocation}
                onChange={handlenewLocationChange}
                placeholder="Enter 8-digit mobile number"
                className="w-full md:w-64 px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                maxLength={8}
              /> */}

              <input
                id="newLocation"
                type="text"
                inputMode="text"
                pattern="\d*"
                value={newLocation}
                onChange={handlenewLocationChange}
                placeholder="Enter Correct Location"
                className="w-full md:w-64 px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                maxLength={25}
                />
            </div>

            <div className="flex gap-3 pt-4">
              <button
                onClick={handleSave}
                //disabled={!isFormValid || isSaving}
                className="px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
              >
                {isSaving ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                ) : (
                  <Save size={16} className="mr-2" />
                )}
                {isSaving ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChangeLocationPage1;