import React, { useState } from 'react';
import {
  Search, Save, Phone, User, CheckCircle, AlertCircle
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { saveCardDistributed } from '../utils/sheetsApi';

interface MemberData {
  kmccId: string;
  name: string;
  district: string;
  constituency: string;
  civilId: string;
  oldMobile: string;
  location: string;
  receipt: string;
  receipt_given: string
}

const CardDistribute: React.FC = () => {
  const { authState } = useAuth();
  const [searchValue, setSearchValue] = useState('');
  const [memberData, setMemberData] = useState<MemberData | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSearch = async () => {
    if (!searchValue.trim()) {
      setError('Please enter a KMCC ID or mobile number');
      return;
    }
    setIsSearching(true); setError(''); setMemberData(null);
    try {
      const sheetId = '1Qp_PQ0WqkzweQoWhLoomDg8E2uM4foSVWS5UvoqTEyk';
      const res = await fetch(
        `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:csv&gid=805376514&timestamp=${Date.now()}`,
        {cache:'no-store'}
      );
      if (!res.ok) throw new Error();
      const rows = (await res.text()).split('\n').slice(1);
      const match = rows.find(r => {
        const cols = r.split(',').map(c => c.replace(/^"|"$/g,'').trim());
        return cols[1] === searchValue || cols[6] === searchValue;
      });
      if (match) {
        const cols = match.split(',').map(c => c.replace(/^"|"$/g,'').trim());
        setMemberData({
          kmccId: cols[1],
          name: cols[2],
          district: cols[3],
          constituency: cols[4],
          civilId: cols[5],
          oldMobile: cols[6],
          location:cols[7],
          receipt:cols[9],
          receipt_given:cols[36],
        });
      } else {
        setError('No member found');
      }
    } catch (e) {
      console.error(e);
      setError('Error searching for member');
    } finally { setIsSearching(false); }
  };

  const handleSave = async () => {
    if (!memberData) return;
    setIsSaving(true); setError(''); setSuccess('');
    try {
      await saveCardDistributed({
        kmccId: memberData.kmccId,
        name: memberData.name,
        changedBy: authState.user?.id || '',
        changedDt: new Date().toISOString(),
      });
      setSuccess('Card Distribution recorded successfully!');
      setMemberData(null);
      setSearchValue('');
    } catch (e) {
      console.error(e);
      setError('Failed to save record. Please try again.');
    } finally {
      setIsSaving(false);
      setTimeout(() => {
        setError('');
        setSuccess('');
      }, 5000);
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-6 space-y-4">
      <h1 className="text-xl font-bold text-center">Card Distribution</h1>

      {success && (
        <div className="p-3 bg-green-50 border border-green-200 rounded flex items-center">
          <CheckCircle className="text-green-600 mr-2" /> 
          <span className="text-green-700 text-sm">{success}</span>
        </div>
      )}
      {error && (
        <div className="p-3 bg-red-50 border border-red-200 rounded flex items-center">
          <AlertCircle className="text-red-600 mr-2" /> 
          <span className="text-red-700 text-sm">{error}</span>
        </div>
      )}

      <div className="bg-white rounded-lg shadow p-4 space-y-3">
        <div className="flex items-center space-x-2 mb-2">
          <Search className="text-gray-500" />
          <h2 className="font-semibold">Search Member</h2>
        </div>
        <div className="flex space-x-2">
          <input
            type="text"
            inputMode="numeric"
            value={searchValue}
            onChange={e => setSearchValue(e.target.value.replace(/\D/g, ''))}
            onKeyPress={e => e.key === 'Enter' && handleSearch()}
            placeholder="KMCC ID or mobile"
            className="flex-1 px-3 py-2 border rounded focus:ring-blue-500 focus:border-blue-500"
          />
          <button
            onClick={handleSearch}
            disabled={isSearching || !searchValue.trim()}
            className="px-4 py-2 bg-blue-600 text-white rounded disabled:opacity-50"
          >
            {isSearching ? '...': <Search />}
          </button>
        </div>
      </div>

      {memberData && (
        <div className="bg-white rounded-lg shadow p-4 space-y-3">
          <div className="flex items-center space-x-2 mb-2">
            <User className="text-gray-500" />
            <h2 className="font-semibold">Member Info</h2>
          </div>
          {[
            ['KMCC ID', memberData.kmccId],
            ['Name', memberData.name],
            ['Mobile', memberData.oldMobile],
            ['District', memberData.district],
            ['Constituency', memberData.constituency],
            ['Civil ID', memberData.civilId],
            ['Area', memberData.location],
            ['Receipt', memberData.receipt],
            ['Receipt Distributed By', memberData.receipt_given],
          ].map(([label, value]) => (
            <div key={label} className="flex justify-between text-sm">
              <span className="font-medium text-gray-500">{label}</span>
              <span className="text-gray-800">{value}</span>
            </div>
          ))}
          {/* Button logic based on receipt_given */}
              <button
                onClick={handleSave}
                disabled={isSaving || (memberData.receipt_given?.length >= 2)}
                className="w-full mt-3 px-4 py-2 bg-green-600 text-white rounded disabled:opacity-50 flex justify-center items-center"
              >
                {isSaving ? (
                  <div className="animate-spin h-4 w-4 border-b-2 border-white"></div>
                ) : (
                  <Save />
                )}
                <span className="ml-2 text-sm">
                  {memberData.receipt_given?.length >= 2 ? 'Already Distributed' : 'Confirm'}
                </span>
              </button>
        </div>
      )}
    </div>
  );
};

export default CardDistribute;
