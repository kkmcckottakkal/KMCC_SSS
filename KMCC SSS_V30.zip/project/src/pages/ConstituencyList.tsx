import React from "react";

const constituencies = [
  { id: 1, constituency: "Constituency A", collectedCount: 50, totalCount: 50 },
  { id: 2, constituency: "Constituency B", collectedCount: 30, totalCount: 50 },
  { id: 3, constituency: "Constituency C", collectedCount: 25, totalCount: 25 },
];

const ConstituencyList = () => {
  return (
    <div className="max-w-3xl mx-auto p-6 bg-gray-50 min-h-screen">
      <h2 className="text-3xl font-bold mb-8 text-center text-gray-800">
        Constituency Collection Status
      </h2>

      {constituencies.map((item) => {
        const percentage = (item.collectedCount / item.totalCount) * 100;
        const isComplete = percentage === 100;

        return (
          <div
            key={item.id}
            className="border rounded-xl p-6 mb-8 shadow-lg bg-white relative"
          >
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold text-gray-900 flex items-center space-x-3">
                <span>{item.constituency}</span>

                {isComplete && (
                  <span
                    className="ml-3 px-3 py-1 rounded-full text-sm font-semibold text-yellow-900 bg-yellow-400 shadow-lg animate-pulse"
                    style={{
                      boxShadow: "0 0 8px 2px rgba(250, 204, 21, 0.8)",
                    }}
                    title="Congratulations!"
                  >
                    Congratulations - 100%
                  </span>
                )}
              </h3>
              <p className="text-md text-gray-600 font-mono">
                {item.collectedCount} / {item.totalCount} collected (
                {percentage.toFixed(1)}%)
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default ConstituencyList;
