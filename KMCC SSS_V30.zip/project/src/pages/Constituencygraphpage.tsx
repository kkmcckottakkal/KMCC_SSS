import React, { useState, useEffect } from 'react';
import { Filter, Download, PieChart, Building, MapPin, Users } from 'lucide-react';
import html2canvas from 'html2canvas';
import { getDistrictsAndConstituencies, getMemberStatusData } from '../utils/sheetsApi';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, LabelList } from 'recharts';
import { useAuth } from '../context/AuthContext';


interface ConstituencySummary {
  distri: string;
  constituency: string;
  collectedby: string;
  totalActive: number;
  collectedCount: number;
  districtCollected: number;
  stateCollected: number;
}

const Constituencygraphpage: React.FC = () => {
  const { authState } = useAuth();
  const [districts, setDistricts] = useState<string[]>(['All']);
  const [constituencies, setConstituencies] = useState<Record<string, string[]>>({ 'All': ['All'] });
  const [selectedDistrict, setSelectedDistrict] = useState<string>('All');
  const [selectedConstituency, setSelectedConstituency] = useState<string>('All');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string>('');
  const [stats, setStats] = useState({
    totalActive: 0,
    totalCollected: 0,
    totalDistrictCollected: 0,
    totalStateCollected: 0
  });
  const [constituencySummary, setConstituencySummary] = useState<ConstituencySummary[]>([]);
  
  const isConstituencyUser = authState.user?.type === 'Constituency';
  const isDistrictUser = authState.user?.type === 'District';
  const userDistrict = authState.user?.district || 'All';
  const userConstituency = authState.user?.constituency || 'All';

  
  useEffect(() => {
    const loadData = async () => {
      try {
        setIsLoading(true);
        setError('');
        
        // Fetch districts and constituencies
        const { districts: districtList, constituencies: constituencyMap } = await getDistrictsAndConstituencies();
        
        /*setDistricts(['All', ...districtList]);
        setConstituencies({
          'All': ['All'],
          ...constituencyMap
        });
        */
        if (isConstituencyUser) {
          setDistricts([userDistrict]);
          setConstituencies({ [userDistrict]: [userConstituency] });
          setSelectedDistrict(userDistrict);
          setSelectedConstituency(userConstituency);
        }
        else  if (isDistrictUser) {
        
          setDistricts([userDistrict]);
          setConstituencies({ [userDistrict]: [userConstituency] });
          setSelectedDistrict(userDistrict);
          setSelectedConstituency(userConstituency);
        }
        else{
          setDistricts([ ...districtList]);
          //setConstituencies([ ...constituencies]);
            //'All': ['All'],
            //'Kottakkal': ['Kottakkal'],
            //...constituencyList          
        }
        // Fetch member data
        const sheetId = '1Qp_PQ0WqkzweQoWhLoomDg8E2uM4foSVWS5UvoqTEyk';
        const response = await fetch(
          `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:csv&gid=805376514&timestamp=${Date.now()}`,
          { cache: 'no-store' }
        );
        
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }

        const csvData = await response.text();
        
        // Parse CSV and process data
        const rows = csvData.split('\n').slice(1); // Skip header
        const constituencyData = new Map<string, ConstituencySummary>();
        let totalStats = {
          totalActive: 0,
          totalCollected: 0,
          totalDistrictCollected: 0,
          totalStateCollected: 0
        };

        rows.forEach(row => {
          const columns = row.split(',').map(col => col.trim().replace(/^"|"$/g, ''));
          const constituency = columns[4];
          const collectedby = columns[10];
          const distri = columns[3];
          const status = columns[8];
          const isCollected = columns[12] === 'Collected';
          const hasDistrictCollection = columns[14]?.length > 0;
          const hasStateCollection = columns[16]?.length > 0;

          if (
            status === 'Active' &&
            (selectedDistrict === 'All' || columns[3] === selectedDistrict) &&
            (selectedConstituency === 'All' || constituency === selectedConstituency)
          ) {
            if (!constituencyData.has(constituency)) {
              constituencyData.set(constituency, {
                constituency,
                collectedby,
                totalActive: 0,
                collectedCount: 0,
                districtCollected: 0,
                stateCollected: 0
              });
            }

            const data = constituencyData.get(constituency)!;
            data.totalActive++;
            totalStats.totalActive++;

            if (isCollected) {
              data.collectedCount++;
              totalStats.totalCollected++;
            }

            if (hasDistrictCollection) {
              data.districtCollected++;
              totalStats.totalDistrictCollected++;
            }

            if (hasStateCollection) {
              data.stateCollected++;
              totalStats.totalStateCollected++;
            }
          }
        });

        const summaryArray = Array.from(constituencyData.values())
          .sort((a, b) => a.constituency.localeCompare(b.constituency));

        setStats(totalStats);
        setConstituencySummary(summaryArray);
      } catch (err) {
        setError('Failed to load data. Please try again later.');
        console.error('Error loading data:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [selectedDistrict, selectedConstituency]);

  const handleDistrictChange = (district: string) => {
    setSelectedDistrict(district);
    setSelectedConstituency('All');
  };

  const downloadReport = async () => {
    const element = document.getElementById('constituency-report');
    if (!element) return;

    try {
      // Clone the element
      const clonedElement = element.cloneNode(true) as HTMLElement;

      // Create a fixed-size container for desktop rendering
      const container = document.createElement('div');
      container.style.width = '1280px'; // Force desktop width
      container.style.padding = '2rem';
      container.style.background = 'white';
      container.style.position = 'fixed';
      container.style.top = '-9999px'; // Hide from view
      container.style.left = '0';
      container.appendChild(clonedElement);
      document.body.appendChild(container);

      const canvas = await html2canvas(clonedElement, {
        scale: 2,
        backgroundColor: '#ffffff',
        logging: false,
        useCORS: true,
        allowTaint: true,
        windowWidth: 1280 // Important to enforce desktop layout
      });

      const link = document.createElement('a');
      link.download = `constituency-report-${new Date().toISOString().split('T')[0]}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();

      // Clean up
      document.body.removeChild(container);
    } catch (error) {
      console.error('Error generating report:', error);
    }
  };


  
  const StatCard: React.FC<{
    title: string;
    value: number;
    total?: number;
    percentages?: { value: number; label: string }[];
    icon: React.ReactNode;
    color: string;
  }> = ({ title, value = 0, total, percentages, icon, color }) => (
    <div className={`bg-white rounded-xl shadow-md p-6 border-l-4 ${color}`}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-gray-600 mb-1">{title}</p>
          <p className="text-2xl font-bold text-gray-900">{value.toLocaleString()}</p>
          {total && total > 0 && (
            <p className="text-sm text-gray-500 mt-1">
              {((value / total) * 100).toFixed(1)}% of total
            </p>
          )}
          {percentages && (
            <div className="mt-2 space-y-1">
              {percentages.map((p, i) => (
                <p key={i} className="text-sm text-gray-500">
                  {p.label}: {p.value.toFixed(1)}%
                </p>
              ))}
            </div>
          )}
        </div>
        <div className={`p-2 rounded-lg ${color.replace('border-', 'bg-').replace('-600', '-100')}`}>
          {icon}
        </div>
      </div>
    </div>
  );


  

   {/* COnstituency Chartt */}

  
 const renderConstituencyBarChart = () => {
  const chartData = constituencySummary
    .map(item => ({
      constituency: item.constituency,
      collectedby: item.collectedby,
      collected: item.collectedCount,
      remaining: item.totalActive - item.collectedCount,
      total: item.totalActive,
    }))
    .sort((a, b) => b.total - a.total);  // Sort descending by total active members

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-8">
      <h2 className="text-lg font-semibold text-gray-700 mb-4">Collected vs Active Members by Constituency</h2>
      <ResponsiveContainer width="100%" height={400}>
        <BarChart
          data={chartData}
          margin={{ top: 20, right: 30, left: 20, bottom: 70 }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis 
            dataKey="constituency" 
            angle={-45} 
            textAnchor="end" 
            interval={0} 
            height={70} 
          />
          <YAxis />
          <Tooltip />
          <Legend verticalAlign="top" />
          <Bar dataKey="collected" stackId="a" fill="#90ee90" name="Collected">
            <LabelList dataKey="collected" position="top" />
          </Bar>
          <Bar dataKey="remaining" stackId="a" fill="#f472b6" name="Remaining">
            <LabelList dataKey="remaining" position="top" />
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};




  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Constituency Collection Overview</h1>
          <p className="mt-1 text-gray-600">
          </p>
        </div>
        <button
          onClick={downloadReport}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          <Download size={16} className="mr-2" />
          Download Report
        </button>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-red-700">{error}</p>
        </div>
      )}

      <div id="constituency-report">
        <div className="mb-8 bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <Filter size={20} className="text-gray-500 mr-2" />
            <h2 className="text-lg font-semibold text-gray-700">Filters</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="district" className="block text-sm font-medium text-gray-700 mb-1">
                District
              </label>
              <select
                id="district"
                value={selectedDistrict}
                onChange={(e) => handleDistrictChange(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                disabled={isLoading}
              >
                {districts.map((district) => (
                  <option key={district} value={district}>
                    {district}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="constituency" className="block text-sm font-medium text-gray-700 mb-1">
                Constituency
              </label>
              <select
                id="constituency"
                value={selectedConstituency}
                onChange={(e) => setSelectedConstituency(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                disabled={isLoading}
              >
                {(constituencies[selectedDistrict] || ['All']).map((constituency) => (
                  <option key={constituency} value={constituency}>
                    {constituency}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Total Active Members"
            value={stats.totalActive}
            icon={<Users className="h-6 w-6 text-blue-600" />}
            color="border-blue-600"
          />
          <StatCard
            title="Approved by Constituency"
            value={stats.totalCollected}
            percentages={[
              { value: (stats.totalCollected / stats.totalActive) * 100, label: 'vs Active' }
            ]}
            icon={<MapPin className="h-6 w-6 text-green-600" />}
            color="border-green-600"
          />
          <StatCard
            title="District Collected"
            value={stats.totalDistrictCollected}
            percentages={[
              { value: (stats.totalDistrictCollected / stats.totalCollected) * 100, label: 'vs Constituency' }
            ]}
            icon={<Building className="h-6 w-6 text-purple-600" />}
            color="border-purple-600"
          />
          <StatCard
            title="State Collected"
            value={stats.totalStateCollected}
            percentages={[
              { value: (stats.totalStateCollected / stats.totalDistrictCollected) * 100, label: 'vs District' }
            ]}
            icon={<PieChart className="h-6 w-6 text-orange-600" />}
            color="border-orange-600"
          />
        </div>


        

        {isLoading ? (
          <div className="h-64 flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-700">Constituency-wise Summary</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Sl. No
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Constituency
                    </th>
                    {/* <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Collected By
                    </th>*/}
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Total Active
                    </th>
                    
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Collected
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      District Collected
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      State Collected
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {constituencySummary.map((item, index) => (
                    <tr key={item.constituency}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {index + 1}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {item.constituency}
                      </td>
                      {/* <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-900">
                        {item.collectedby}
                      </td>*/}
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-900">
                        {item.totalActive}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-blue-600">
                        {item.collectedCount}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-purple-600">
                        {item.districtCollected}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-orange-600">
                        {item.stateCollected}
                      </td>
                    </tr>
                  ))}
                  {/* Total Row */}
                  <tr className="bg-gray-50 font-semibold">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500"></td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Total
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-900">
                      {stats.totalActive}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-blue-600">
                      {stats.totalCollected}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-purple-600">
                      {stats.totalDistrictCollected}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-orange-600">
                      {stats.totalStateCollected}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

           
                <div>
                  {renderConstituencyBarChart()}
              {/* other content */}
            </div>
         
    </div>
  );
};

export default Constituencygraphpage;