import React, { useState, useEffect } from 'react';
import { Filter } from 'lucide-react';
import { validateKmccId, getDistrictsAndConstituencies, saveStateReceiveRecord } from '../utils/sheetsApi';
import { useAuth } from '../context/AuthContext';

const StateReceivePage: React.FC = () => {
  const { authState } = useAuth();
  const [districts, setDistricts] = useState<string[]>([]);
  const [constituencies, setConstituencies] = useState<string[]>([]);
  const [selectedDistrict, setSelectedDistrict] = useState<string>('All');
  const [selectedConstituency, setSelectedConstituency] = useState<string>('All');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string>('');
  const [successMessage, setSuccessMessage] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [members, setMembers] = useState<Array<{
    slNo: number;
    kmccId: string;
    name: string;
    district: string;
    constituency: string;
    collectedBy: string;
    constCollectedBy: string;
    districtCollectedBy: string;
    stateCollectedBy: string;
  }>>([]);
  const [districtMap, setDistrictMap] = useState<Record<string, string[]>>({});
  const [processingIds, setProcessingIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    const loadData = async () => {
      try {
        setIsLoading(true);
        setError('');

        const { districts: districtList, districtMap: newDistrictMap } = await getDistrictsAndConstituencies();
        setDistricts(districtList);
        setDistrictMap(newDistrictMap);

        if (selectedDistrict === 'All') {
          setConstituencies(newDistrictMap['All'] || ['All']);
        } else {
          setConstituencies(newDistrictMap[selectedDistrict] || ['All']);
        }

        const sheetId = '1Qp_PQ0WqkzweQoWhLoomDg8E2uM4foSVWS5UvoqTEyk';
        const response = await fetch(
          `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:csv&gid=805376514&timestamp=${Date.now()}`,
          { cache: 'no-store' }
        );

        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }

        const csvData = await response.text();
        const rows = csvData.split('\n').slice(1);

        const parsedMembers = rows
          .map((row, index) => {
            const columns = row.split(',').map(col => col.trim().replace(/^"|"$/g, ''));
            if (columns.length < 17) return null;

            return {
              slNo: index + 1,
              kmccId: columns[1] || '',
              name: columns[2] || '',
              district: columns[3] || '',
              constituency: columns[4] || '',
              collectedBy: columns[10] || '',
              constCollectedBy: columns[10] || '',
              districtCollectedBy: columns[14] || '',
              stateCollectedBy: columns[16] || ''
            };
          })
          .filter((member): member is NonNullable<typeof member> =>
            member !== null &&
            member.kmccId &&
            member.districtCollectedBy && // Must be collected by district
            !member.stateCollectedBy && // Not yet collected by state
            (selectedDistrict === 'All' || member.district === selectedDistrict) &&
            (selectedConstituency === 'All' || member.constituency === selectedConstituency)
          );

        setMembers(parsedMembers);
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Failed to load data. Please try again later.';
        setError(errorMessage);
        console.error('Error loading data:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [selectedDistrict, selectedConstituency]);

  const handleReceive = async (kmccId: string, name: string) => {
    if (processingIds.has(kmccId)) return;

    try {
      setError('');
      setSuccessMessage('');
      setProcessingIds(prev => new Set(prev).add(kmccId));

      await saveStateReceiveRecord({
        idNumber: kmccId,
        name: name,
        dateTime: new Date().toLocaleString('en-US', { timeZone: 'Asia/Kuwait' }),
        remarks: '',
        verifiedBy: authState.user?.id || ''
      });

      await validateKmccId(kmccId);

      setMembers(prevMembers =>
        prevMembers.filter(member => member.kmccId !== kmccId)
      );

      setSuccessMessage(`Successfully received payment for ${name}`);
      setTimeout(() => setSuccessMessage(''), 3000);
    } catch (error: any) {
      console.error('Error updating status:', error);
      setError(error.message || 'Failed to update status. Please try again.');
      setTimeout(() => setError(''), 3000);
    } finally {
      setProcessingIds(prev => {
        const updated = new Set(prev);
        updated.delete(kmccId);
        return updated;
      });
    }
  };

  const filteredMembers = members.filter((member) =>
    member.kmccId.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.collectedBy.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">State Collection</h1>
        <p className="mt-1 text-gray-600">Manage state-level collections</p>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-red-700">{error}</p>
        </div>
      )}

      {successMessage && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-md">
          <p className="text-green-700">{successMessage}</p>
        </div>
      )}

      <div className="mb-8 bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center mb-4">
          <Filter size={20} className="text-gray-500 mr-2" />
          <h2 className="text-lg font-semibold text-gray-700">Filters</h2>
        </div>
        <div className="flex flex-col md:flex-row gap-4">
          <select
            value={selectedDistrict}
            onChange={(e) => {
              setSelectedDistrict(e.target.value);
              setSelectedConstituency('All');
            }}
            className="w-full md:w-64 px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
            disabled={isLoading}
          >
            {districts.map(district => (
              <option key={district} value={district}>
                {district}
              </option>
            ))}
          </select>

          <select
            value={selectedConstituency}
            onChange={(e) => setSelectedConstituency(e.target.value)}
            className="w-full md:w-64 px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
            disabled={isLoading || constituencies.length === 0}
          >
            {constituencies.map(c => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="mb-6">
        <input
          type="text"
          placeholder="Search by KMCC ID, Name or Collected By"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full md:w-96 px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {isLoading ? (
        <div className="h-64 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sl. No</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">KMCC ID</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">District</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Constituency</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Const Collected By</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">District Collected By</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredMembers.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-4 text-center text-gray-500">
                      No records found
                    </td>
                  </tr>
                ) : (
                  filteredMembers.map((member, index) => (
                    <tr key={member.kmccId}>
                      <td className="px-6 py-4 text-sm text-gray-500">{index + 1}</td>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">{member.kmccId}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{member.name}</td>
                      <td className="px-6 py-4 text-sm text-gray-500">{member.district}</td>
                      <td className="px-6 py-4 text-sm text-gray-500">{member.constituency}</td>
                      <td className="px-6 py-4 text-sm text-gray-500">{member.constCollectedBy}</td>
                      <td className="px-6 py-4 text-sm text-gray-500">{member.districtCollectedBy}</td>
                      <td className="px-6 py-4 text-right text-sm font-medium">
                        <button
                          onClick={() => handleReceive(member.kmccId, member.name)}
                          className={`font-medium ${processingIds.has(member.kmccId)
                            ? 'text-gray-400 cursor-not-allowed'
                            : 'text-green-600 hover:text-green-900'}`}
                          disabled={processingIds.has(member.kmccId)}
                        >
                          {processingIds.has(member.kmccId) ? 'Processing...' : 'Receive'}
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default StateReceivePage;