import React from 'react';
import { FaWhatsapp } from 'react-icons/fa';

type ContactProps = {
  name: string;
  desig: string;
  phone: string;
  imgUrl: string;
};


const ContactCard: React.FC<ContactProps> = ({ name,desig,phone, imgUrl }) => {
  return (
    <div className="bg-white shadow-2xl rounded-3xl p-6 max-w-xs w-full text-center transition-transform transform hover:scale-105 duration-300">
      <div className="relative">
        <img
          src={imgUrl}
          alt={name}
          className="w-16 h-16 mx-auto rounded-full border-2 border-green-500 shadow-md"
        />
      </div>
      <h2 className="text-xl font-semibold text-gray-800 mt-4 mb-1">{name}</h2>
      <p className="text-sm text-gray-500 mb-2">{desig}</p>

      

      <div className="bg-green-100 text-green-800 px-4 py-2 rounded-full inline-flex items-center gap-2 justify-center mx-auto mb-2">
        {/*<FaWhatsapp className="text-lg" />*/}
        <a
          href={`https://wa.me/${phone.replace(/[^0-9]/g, '')}`}
          target="_blank"
          rel="noopener noreferrer"
          className="font-medium tracking-wide text-green-800 hover:underline"
        >
          {phone}
        </a>
      </div>


      <p className="text-xs text-gray-400">WhatsApp messages only</p>
    </div>
  );
};

const ContactUs = () => {
  const contacts = [
    {
      name: 'Sadakkathulla',
      desig: 'IT Wing',
      phone: '+965 69601274',
      imgUrl: 'https://lh3.googleusercontent.com/d/1uSZG-9qjWQCOs6DfY-YjNmBsDyrtEILc',
    },
    {
      name: 'Nasar',
      desig: 'IT Wing',
      phone: '+965 9979 3739',
      imgUrl: 'https://lh3.googleusercontent.com/d/1uSZG-9qjWQCOs6DfY-YjNmBsDyrtEILc',
    },
    {
      name: 'Gafoor Atholi',
      desig: 'Security Scheme Wing',
      phone: '+965 9908 6817',
      imgUrl: 'https://lh3.googleusercontent.com/d/1uSZG-9qjWQCOs6DfY-YjNmBsDyrtEILc',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-gray-100 px-6 py-10">
      <h1 className="text-2xl md:text-3xl font-bold text-center text-green-800 mb-10">
        Thank you for contacting KMCC IT Wing
      </h1>

      <div className="flex flex-col md:flex-row justify-center items-center gap-8">
        {contacts.map(({ name, desig, phone, imgUrl }) => (
          <ContactCard key={name} name={name} desig={desig} phone={phone} imgUrl={imgUrl} />
        ))}
      </div>
    </div>
  );
};

export default ContactUs;