import React, { useState, useEffect } from 'react';
import { Download, Filter, Search } from 'lucide-react';
import { getDistrictsAndConstituencies } from '../utils/sheetsApi';

interface CancellationSummary {
  district: string;
  constituency: string;
  totalCount: number;
  cancelledCount: number;
  percentageCancelled: number;
}

const CancellationListPage: React.FC = () => {
  const [districts, setDistricts] = useState<string[]>(['All']);
  const [constituencies, setConstituencies] = useState<Record<string, string[]>>({ 'All': ['All'] });
  const [selectedDistrict, setSelectedDistrict] = useState<string>('All');
  const [selectedConstituency, setSelectedConstituency] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string>('');
  const [summaryData, setSummaryData] = useState<CancellationSummary[]>([]);
  const [totals, setTotals] = useState<CancellationSummary>({
    district: 'Total',
    constituency: '',
    totalCount: 0,
    cancelledCount: 0,
    percentageCancelled: 0
  });

  useEffect(() => {
    const loadData = async () => {
      try {
        setIsLoading(true);
        setError('');
        
        // Fetch districts and constituencies
        const { districts: districtList, constituencies: constituencyMap } = await getDistrictsAndConstituencies();
        setDistricts(['All', ...districtList]);
        setConstituencies({
          'All': ['All'],
          ...constituencyMap
        });

        // Fetch member data
        const sheetId = '1Qp_PQ0WqkzweQoWhLoomDg8E2uM4foSVWS5UvoqTEyk';
        const response = await fetch(
          `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:csv&gid=805376514&timestamp=${Date.now()}`,
          { cache: 'no-store' }
        );
        
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }

        const csvData = await response.text();
        
        // Parse CSV and process data, explicitly skipping the header row
        const rows = csvData
            .split('\n')
            .filter((row, index) => index > 1 && row.trim() !== '');
        
        const summaryMap = new Map<string, CancellationSummary>();
        let grandTotalCount = 0;
        let grandCancelledCount = 0;

        rows.forEach(row => {
          const columns = row.split(',').map(col => col.trim().replace(/^"|"$/g, ''));
          
          // Skip empty rows or rows without required data
          if (!columns[1] || !columns[3] || !columns[4]) return;

          const district = columns[3];
          const constituency = columns[4];
          const status = (columns[8] || '').toLowerCase();
          const key = `${district}-${constituency}`;

          if (
            district && 
            constituency && 
            (selectedDistrict === 'All' || district === selectedDistrict) &&
            (selectedConstituency === 'All' || constituency === selectedConstituency)
          ) {
            if (!summaryMap.has(key)) {
              summaryMap.set(key, {
                district,
                constituency,
                totalCount: 0,
                cancelledCount: 0,
                percentageCancelled: 0
              });
            }

            const summary = summaryMap.get(key)!;
            summary.totalCount++;
            grandTotalCount++;
            
            if (status === 'cancelled') {
              summary.cancelledCount++;
              grandCancelledCount++;
            }
          }
        });

        // Calculate percentages and create final array
        const summaryArray = Array.from(summaryMap.values())
          .map(summary => ({
            ...summary,
            percentageCancelled: Number(((summary.cancelledCount / summary.totalCount) * 100).toFixed(1))
          }))
          .sort((a, b) => 
            a.district.localeCompare(b.district) || 
            a.constituency.localeCompare(b.constituency)
          );

        // Set totals
        setTotals({
          district: 'Total',
          constituency: '',
          totalCount: grandTotalCount,
          cancelledCount: grandCancelledCount,
          percentageCancelled: Number(((grandCancelledCount / grandTotalCount) * 100).toFixed(1))
        });

        setSummaryData(summaryArray);
      } catch (err) {
        setError('Failed to load data. Please try again later.');
        console.error('Error loading data:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [selectedDistrict, selectedConstituency]);

  const handleDistrictChange = (district: string) => {
    setSelectedDistrict(district);
    setSelectedConstituency('All');
  };

  const filteredData = summaryData.filter(item => {
    const searchLower = searchTerm.toLowerCase();
    return (
      item.district.toLowerCase().includes(searchLower) ||
      item.constituency.toLowerCase().includes(searchLower)
    );
  });

  const exportToCSV = () => {
    const headers = ['Sl.No', 'District', 'Constituency', 'Total Count', 'Cancelled Count', '% Cancelled'];
    const csvContent = [
      headers.join(','),
      ...filteredData.map((item, index) => [
        index + 1,
        item.district,
        item.constituency,
        item.totalCount,
        item.cancelledCount,
        `${item.percentageCancelled}%`
      ].join(',')),
      ['', 'Total', '', totals.totalCount, totals.cancelledCount, `${totals.percentageCancelled}%`].join(',')
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `cancellation-report-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Cancellation Report</h1>
          <p className="mt-1 text-gray-600">
            {/*} View district and constituency-wise cancellation statistics*/}
          </p>
        </div>
        <button
          onClick={exportToCSV}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          <Download size={16} className="mr-2" />
          Export CSV
        </button>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-red-700">{error}</p>
        </div>
      )}

      <div className="mb-8 bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center mb-4">
          <Filter size={20} className="text-gray-500 mr-2" />
          <h2 className="text-lg font-semibold text-gray-700">Filters</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label htmlFor="district" className="block text-sm font-medium text-gray-700 mb-1">
              District
            </label>
            <select
              id="district"
              value={selectedDistrict}
              onChange={(e) => handleDistrictChange(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
              disabled={isLoading}
            >
              {districts.map((district) => (
                <option key={district} value={district}>
                  {district}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="constituency" className="block text-sm font-medium text-gray-700 mb-1">
              Constituency
            </label>
            <select
              id="constituency"
              value={selectedConstituency}
              onChange={(e) => setSelectedConstituency(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
              disabled={isLoading}
            >
              {(constituencies[selectedDistrict] || ['All']).map((constituency) => (
                <option key={constituency} value={constituency}>
                  {constituency}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="search" className="block text-sm font-medium text-gray-700 mb-1">
              Search
            </label>
            <div className="relative">
              <input
                type="text"
                id="search"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by district or constituency..."
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
              />
              <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            </div>
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="h-64 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Sl. No
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    District
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Constituency
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Total Count
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Active Count
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Cancelled Count
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    % Cancelled
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredData.map((item, index) => (
                  <tr key={`${item.district}-${item.constituency}`}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {index + 1}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {item.district}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {item.constituency}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-900">
                      {item.totalCount}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-green-600">
                        {item.totalCount - item.cancelledCount}
                      </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-red-600">
                      {item.cancelledCount}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right font-medium text-gray-900">
                      {item.percentageCancelled}%
                    </td>
                  </tr>
                ))}
                {/* Total Row */}
                <tr className="bg-gray-50 font-semibold">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500"></td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900" colSpan={2}>
                    Total
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-900">
                    {totals.totalCount}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-900">
                    {totals.totalCount - totals.cancelledCount}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-red-600">
                    {totals.cancelledCount}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-right font-medium text-gray-900">
                    {totals.percentageCancelled}%
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default CancellationListPage;