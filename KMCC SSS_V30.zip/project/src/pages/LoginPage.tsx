import React from 'react';
import { Shield } from 'lucide-react';
import LoginForm from '../components/LoginForm';

const LoginPage: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-blue-50 to-blue-100 px-4">
      <div className="w-full max-w-md text-center mb-6">
        <div className="flex justify-center mb-4">
          <img 
            src="https://lh3.googleusercontent.com/d/1uSZG-9qjWQCOs6DfY-YjNmBsDyrtEILc" 
            alt="KMCC Logo" 
            className="w-32 h-auto"
          />
        </div>
        <h1 className="text-3xl font-bold text-gray-800">KMCC SSS - 2025</h1>
        <p className="mt-2 text-gray-600">Social Security Scheme Collection</p>
      </div>
      
      <LoginForm />
      
      <div className="mt-8 text-center text-gray-500 text-sm flex items-center">
        <Shield size={16} className="mr-1" />
        KMCC IT Wing - Kuwait
      </div>
    </div>
  );
};

export default LoginPage;