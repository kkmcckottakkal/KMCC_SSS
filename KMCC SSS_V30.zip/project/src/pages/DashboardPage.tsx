import React, { useState, useEffect } from 'react';
import { Users, AlertCircle, Filter, PieChart, Download, CheckCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { getDistrictsAndConstituencies, getMemberStatusData } from '../utils/sheetsApi';
import StatusPieChart from '../components/StatusPieChart';
import html2canvas from 'html2canvas';
//import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LabelList } from 'recharts';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  LabelList,
  Cell
} from 'recharts';


interface DistrictSummary {
  district: string;
  totalMembers: number;
  activeMembers: number;
  cancelledMembers: number;
  constituencyCollected: number;
  pendingPercentage: number;
  districtCollected: number;
  stateCollected: number;
}

const DashboardPage: React.FC = () => {
  const { authState } = useAuth();
  const [districts, setDistricts] = useState<string[]>(['All']);
  const [constituencies, setConstituencies] = useState<Record<string, string[]>>({ 'All': ['All'] });
  const [selectedDistrict, setSelectedDistrict] = useState<string>('All');
  const [selectedConstituency, setSelectedConstituency] = useState<string>('All');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string>('');
  const [stats, setStats] = useState({
    active: 0,
    cancelled: 0,
    collected: 0,
    total: 0,
    districtSummary: [] as DistrictSummary[]
  });

  useEffect(() => {
    const loadData = async () => {
      try {
        setIsLoading(true);
        const [{ districts: districtList, constituencies: constituencyMap }] = await Promise.all([
          getDistrictsAndConstituencies()
        ]);
        
        // Ensure 'All' option is included
        const updatedDistricts = ['All', ...districtList];
        const updatedConstituencies = {
          'All': ['All'],
          ...constituencyMap
        };
        
        setDistricts(updatedDistricts);
        setConstituencies(updatedConstituencies);

        // Fetch member data
        const sheetId = '1Qp_PQ0WqkzweQoWhLoomDg8E2uM4foSVWS5UvoqTEyk';
        const response = await fetch(
          `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:csv&gid=805376514&timestamp=${Date.now()}`,
          { cache: 'no-store' }
        );
        
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }

        const csvData = await response.text();
        const rows = csvData.split('\n').slice(1).filter(row => row.trim().length > 0); // Skip header row
        
        const districtMap = new Map<string, DistrictSummary>();
        let totalActive = 0;
        let totalCancelled = 0;
        let totalCollected = 0;

        rows.forEach(row => {
          const columns = row.split(',').map(col => col.trim().replace(/^"|"$/g, ''));
          const district = columns[3];
          const constituency = columns[4];
          const status = columns[8]?.toLowerCase();
          const isCollected = columns[12] === 'Collected';
          const isDistrictCollected = columns[14]?.length > 0;
          const isStateCollected = columns[16]?.length > 0;

          if (!district || !status) return;

          if (!districtMap.has(district)) {
            districtMap.set(district, {
              district,
              totalMembers: 0,
              activeMembers: 0,
              cancelledMembers: 0,
              constituencyCollected: 0,
              pendingPercentage: 0,
              districtCollected: 0,
              stateCollected: 0
            });
          }

          const summary = districtMap.get(district)!;
          summary.totalMembers++;

          if (status === 'active') {
            summary.activeMembers++;
            totalActive++;
            if (isCollected) {
              summary.constituencyCollected++;
              totalCollected++;
            }
            if (isDistrictCollected) summary.districtCollected++;
            if (isStateCollected) summary.stateCollected++;
          } else if (status === 'cancelled') {
            summary.cancelledMembers++;
            totalCancelled++;
          }
        });

        // Calculate pending percentages and create final array
        const summaryArray = Array.from(districtMap.values())
          .map(summary => ({
            ...summary,
            pendingPercentage: summary.activeMembers > 0 
              ? ((summary.activeMembers - summary.constituencyCollected) / summary.activeMembers) * 100 
              : 0
          }))
          .sort((a, b) => b.activeMembers - a.activeMembers);

        // Add totals row
        const totals: DistrictSummary = {
          district: 'Total',
          totalMembers: summaryArray.reduce((sum, item) => sum + item.totalMembers, 0),
          activeMembers: totalActive,
          cancelledMembers: totalCancelled,
          constituencyCollected: totalCollected,
          pendingPercentage: totalActive > 0 ? ((totalActive - totalCollected) / totalActive) * 100 : 0,
          districtCollected: summaryArray.reduce((sum, item) => sum + item.districtCollected, 0),
          stateCollected: summaryArray.reduce((sum, item) => sum + item.stateCollected, 0)
        };
        summaryArray.push(totals);

        setStats({
          active: totalActive,
          cancelled: totalCancelled,
          collected: totalCollected,
          total: totalActive + totalCancelled,
          districtSummary: summaryArray
        });
      } catch (err) {
        setError('Failed to load data. Please try again later.');
        console.error('Error loading data:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [selectedDistrict, selectedConstituency]);

  const handleDistrictChange = (district: string) => {
    setSelectedDistrict(district);
    setSelectedConstituency('All');
  };

  const downloadReport = async () => {
    const original = document.getElementById('dashboard-content');
    if (!original) return;

    try {
      // Clone the original element
      const clone = original.cloneNode(true) as HTMLElement;

      // Force desktop layout styles
      clone.style.position = 'fixed';
      clone.style.top = '0';
      clone.style.left = '0';
      clone.style.width = '1440px'; // Desktop width
      clone.style.minHeight = '1000px';
      clone.style.zIndex = '-1';
      clone.style.backgroundColor = '#ffffff';
      clone.style.padding = '2rem';
      clone.style.overflow = 'visible';

      // Optional: add a custom class if your Tailwind desktop styles are class-based
      clone.classList.add('desktop-screenshot');

      // Copy canvas content manually (for charts)
      const origCanvases = original.querySelectorAll('canvas');
      const cloneCanvases = clone.querySelectorAll('canvas');
      origCanvases.forEach((origCanvas, i) => {
        const ctx = cloneCanvases[i]?.getContext('2d');
        if (ctx) ctx.drawImage(origCanvas, 0, 0);
      });

      // Append to body
      document.body.appendChild(clone);
      await new Promise((resolve) => setTimeout(resolve, 300)); // allow rendering

      // Capture screenshot
      const canvas = await html2canvas(clone, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff',
      });

      // Cleanup
      document.body.removeChild(clone);

      // Download
      const link = document.createElement('a');
      link.download = `membership-summary-${new Date().toISOString().split('T')[0]}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch (err) {
      console.error('Error generating screenshot:', err);
    }
  };
  
  const StatCard: React.FC<{
    title: string;
    value: number;
    total?: number;
    icon: React.ReactNode;
    color: string;
  }> = ({ title, value = 0, total, icon, color }) => (
    <div className={`bg-white rounded-xl shadow-md p-6 border-l-4 ${color}`}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-gray-600 mb-1">{title}</p>
          <p className="text-2xl font-bold text-gray-900">{value?.toLocaleString() || '0'}</p>
          {total && total > 0 && (
            <p className="text-sm text-gray-500 mt-1">
              {((value / total) * 100).toFixed(1)}% of total
            </p>
          )}
        </div>
        <div className={`p-2 rounded-lg ${color.replace('border-', 'bg-').replace('-600', '-100')}`}>
          {icon}
        </div>
      </div>
    </div>
  );



const renderActiveMembersBarChart = () => {
  const filteredData = stats.districtSummary
    .filter(d => d.district !== 'Total')
    .map(d => ({
      district: d.district,
      collected: d.constituencyCollected,
      remaining: d.activeMembers - d.constituencyCollected,
    }));

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mt-10">
      <h2 className="text-lg font-semibold text-gray-700 mb-1">Active Members by District</h2>
      <p className="text-sm text-gray-500 mb-4">
        Light Green = Collected, Pink = Not Collected
      </p>

      <ResponsiveContainer width="100%" height={500}>
        <BarChart data={filteredData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="district" />
          <YAxis />
          <Tooltip />
          <Legend />

          {/* Collected part (light green) */}
          <Bar dataKey="collected" stackId="a" fill="#90ee90" name="Collected" />

          {/* Remaining part (pink) */}
          <Bar dataKey="remaining" stackId="a" fill="#f472b6" name="Not Collected">
            {/* Show total value at top */}
            <LabelList dataKey={(d) => d.collected + d.remaining} position="top" />
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

  

  
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            District-wise Membership Summary – KMCC Social Security Scheme 2025
          </h1>
        </div>
        <button
          onClick={downloadReport}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          <Download size={16} className="mr-2" />
          Download Report
        </button>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-red-700">{error}</p>
        </div>
      )}

      <div id="dashboard-content">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Total Members"
            value={stats.total}
            icon={<Users className="h-6 w-6 text-blue-600" />}
            color="border-blue-600"
          />
          <StatCard
            title="Active Members"
            value={stats.active}
            total={stats.total}
            icon={<Users className="h-6 w-6 text-yellow-600" />}
            color="border-yellow-600"
          />
          <StatCard
            title="Cancelled Members"
            value={stats.cancelled}
            total={stats.total}
            icon={<AlertCircle className="h-6 w-6 text-red-600" />}
            color="border-red-600"
          />
          <StatCard
            title="Collected Members"
            value={stats.collected}
            total={stats.active}
            icon={<CheckCircle className="h-6 w-6 text-green-600" />}
            color="border-green-600"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center mb-4">
              <PieChart size={20} className="text-gray-500 mr-2" />
              <h2 className="text-lg font-semibold text-gray-700">Membership Status</h2>
            </div>
            <div className="h-64">
              <StatusPieChart
                active={stats.active}
                cancelled={stats.cancelled}
                collected={stats.collected}
              />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center mb-4">
              <Filter size={20} className="text-gray-500 mr-2" />
              <h2 className="text-lg font-semibold text-gray-700">Filters</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="district" className="block text-sm font-medium text-gray-700 mb-1">
                  District
                </label>
                <select
                  id="district"
                  value={selectedDistrict}
                  onChange={(e) => handleDistrictChange(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  disabled={isLoading}
                >
                  {districts.map((district) => (
                    <option key={district} value={district}>
                      {district}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="constituency" className="block text-sm font-medium text-gray-700 mb-1">
                  Constituency
                </label>
                <select
                  id="constituency"
                  value={selectedConstituency}
                  onChange={(e) => setSelectedConstituency(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  disabled={isLoading}
                >
                  {(constituencies[selectedDistrict] || ['All']).map((constituency) => (
                    <option key={constituency} value={constituency}>
                      {constituency}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-700">District-wise Summary</h2>
          </div>
          {/*<div className="overflow-x-auto">
             <table className="min-w-full divide-y divide-gray-200">*/}
          <div className="overflow-x-auto">
            <table className="w-full min-w-[1200px] divide-y divide-gray-200">


              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Sl. No
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    District
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Total Members
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Active Members
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Cancl- Members
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Const Colctd
                  </th>
                  
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    % Collected
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Dist Colctd
                  </th>
                 
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    State Colctd
                  </th>

                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Const Amount
                  </th>
                   <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Dist Amount
                  </th>
                  
                   <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    State Amount
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {stats.districtSummary.map((item, index) => (
                  <tr key={item.district} className={item.district === 'Total' ? 'bg-gray-50 font-semibold' : ''}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {item.district === 'Total' ? '' : index + 1}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {item.district}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-900">
                      {item.totalMembers}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-yellow-600">
                      {item.activeMembers}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-red-600">
                      {item.cancelledMembers}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-green-600">
                      {item.constituencyCollected}
                    </td>
                    
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-blue-600">
                      {/*{item.pendingPercentage.toFixed(1)}%*/}
                      {item.activeMembers > 0
                        ? ((item.constituencyCollected / item.activeMembers) * 100).toFixed(1) + "%"
                        : "0%"}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-purple-600">
                      {item.districtCollected}
                    </td>
                     
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-orange-600">
                      {item.stateCollected}
                    </td>

                     <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-green-600">
                      {(item.constituencyCollected * 3).toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-green-600">
                      {(item.districtCollected * 3).toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-green-600">
                      {(item.stateCollected * 3).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Insert the Active Members Bar Chart here */}
        {renderActiveMembersBarChart()}
        
      </div>
    </div>
  );
};

export default DashboardPage;