import React, { useState, useEffect } from 'react';
import { Filter, Download, Copy, Check } from 'lucide-react';
import { getDistrictsAndConstituencies } from '../utils/sheetsApi';
import { useAuth } from '../context/AuthContext';




const collectedbyme: React.FC = () => {
  const { authState } = useAuth();
  const [districts, setDistricts] = useState<string[]>(['All']);
  const [constituencies, setConstituencies] = useState<Record<string, string[]>>({ 'All': ['All'] });
  const [selectedDistrict, setSelectedDistrict] = useState<string>('All');
  const [selectedConstituency, setSelectedConstituency] = useState<string>('All');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string>('');
  const [members, setMembers] = useState<Array<{
    kmccId: string;
    name: string;
    mobile: string;
    place: string;
    district: string;
    constituency: string;
    receipt: string;
    approvedby: string;
    districtby: string;
    stateby: string;
  }>>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [copied, setCopied] = useState(false);
  const itemsPerPage = 10;

  // Check if user is constituency type
  const isConstituencyUser = authState.user?.type === 'Constituency';
  const userDistrict = authState.user?.district || 'All';
  const userConstituency = authState.user?.constituency || 'All';

  useEffect(() => {
    const loadData = async () => {
      try {
        setIsLoading(true);
        setError('');
        
        // Fetch districts and constituencies
        const { districts: districtList, constituencies: constituencyList } = await getDistrictsAndConstituencies();
        
        
        // Set districts and constituencies based on user type
        if (isConstituencyUser) {
          setDistricts([userDistrict]);
          setConstituencies({ [userDistrict]: [userConstituency] });
          setSelectedDistrict(userDistrict);
          setSelectedConstituency(userConstituency);
        } 
       else {
          setDistricts([ ...districtList]);
          setConstituencies({
            //'All': ['All'],
            //'Kottakkal': ['Kottakkal'],
            //...constituencyList
          });
        }

        // Fetch member data
        const sheetId = '1Qp_PQ0WqkzweQoWhLoomDg8E2uM4foSVWS5UvoqTEyk';
        const response = await fetch(
          `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:csv&gid=805376514&timestamp=${Date.now()}`,
          { cache: 'no-store' }
        );
        
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }

        const csvData = await response.text();
        const rows = csvData.split('\n').slice(1);
        const loggedInUserName = authState.user?.id || '';


        const parsedMembers = rows
          .map(row => {
            const columns = row.split(',').map(col => col.trim().replace(/^"|"$/g, ''));
            return {
              kmccId: columns[1] || '',
              name: columns[2] || '',
              district: columns[3] || '',
              constituency: columns[4] || '',
              mobile: columns[6] || '',
              place: columns[7] || '',
              status: columns[8] || '',
              receipt: columns[9] || '',
              approvedby: columns[10] || '',
              districtby: columns[14] || '',
              stateby: columns[16] || ''
            };
          })
          .filter(member =>
            member.kmccId &&
            member.status.toLowerCase() === 'active' &&
            member.approvedby.toLowerCase() === loggedInUserName.toLowerCase()
          )
        .sort((a, b) => {
    // Remove non-digit characters and convert to number
          const aReceipt = Number((a.receipt || '').replace(/\D/g, '')) || 0;
          const bReceipt = Number((b.receipt || '').replace(/\D/g, '')) || 0;
          return bReceipt - aReceipt; // Descending
        });
     

        setMembers(parsedMembers);
      } catch (err) {
        setError('Failed to load data. Please try again later.');
        console.error('Error loading data:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [selectedDistrict, selectedConstituency, isConstituencyUser, userDistrict, userConstituency]);

  const handleDistrictChange = (district: string) => {
    if (!isConstituencyUser) {
      setSelectedDistrict(district);
      setSelectedConstituency('All');
      setCurrentPage(1);
    }
  };

  const handleConstituencyChange = (constituency: string) => {
    if (!isConstituencyUser) {
      setSelectedConstituency(constituency);
      setCurrentPage(1);
    }
  };

  const handleSearch = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(event.target.value);
    setCurrentPage(1);
  };
/*
  const filteredMembers = members.filter(member => {
    const searchLower = searchTerm.toLowerCase();
    return (
      member.kmccId.toLowerCase().includes(searchLower) ||
      member.name.toLowerCase().includes(searchLower) ||
      member.mobile.toLowerCase().includes(searchLower) ||
      member.place.toLowerCase().includes(searchLower)
    );
  });
*/

  const filteredMembers = members.filter(member => {
  const searchLower = searchTerm.toLowerCase();
  return (
    member.kmccId.toLowerCase().includes(searchLower) ||
    member.name.toLowerCase().includes(searchLower) ||
    member.mobile.toLowerCase().includes(searchLower) ||
    member.place.toLowerCase().includes(searchLower) ||
    member.constituency.toLowerCase().includes(searchLower)||
    member.approvedby.toLowerCase().includes(searchLower)
  );
});

  
  const totalPages = Math.ceil(filteredMembers.length / itemsPerPage);
  const paginatedMembers = filteredMembers.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const copyToClipboard = async () => {
    try {
      /*
      const header = `*Assalamu Alaikum,*  
    Dear all,  
    Below is the Security Scheme Collection List from our *${selectedConstituency}* Constituency, 
    Those who haven't submitted yet, please hand it over to the concerned persons at the earliest.\n\n`;
*/

      const header = `*Assalamu Alaikum,*  
      Dear all,  
      Below is the Security Scheme Collection List from our *${selectedConstituency}* Constituency.  
      Total Members: *${filteredMembers.length}* \n\n`;

/*
      const formattedText = header + filteredMembers
        .map((member, index) => 
          `${index + 1}.\t${member.kmccId}\t${member.name}\t*${member.mobile}*\t${member.place}`
        )
        .join('\n');
*/
  /*    const formattedText = header + filteredMembers
  .map((member, index) => 
    `${index + 1}.\t${member.kmccId}\t${member.name}\t*${member.mobile}*\t${member.place}\t${member.receipt}`
  )
  .join('\n');
*/

      const formattedText = header + filteredMembers
      .sort((a, b) => a.receipt.localeCompare(b.receipt)) // Sort by receipt (ascending)
      .map((member, index) => 
        `${index + 1}.\t${member.kmccId}\t${member.name}\t*${member.mobile}*\t${member.place}\t${member.receipt}\t${member.approvedby}\t${member.constituency}`
      )
      .join('\n');

      
      await navigator.clipboard.writeText(formattedText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
      setError('Failed to copy to clipboard');
    }
  };
/*
  const exportToCSV = () => {
    const headers = ['S.No', 'KMCC ID', 'Name', 'Mobile', 'Place', 'District', 'Constituency'];
    const csvContent = [
      headers.join(','),
      ...filteredMembers.map((member, index) => 
        [
          index + 1,
          member.kmccId,
          member.name,
          member.mobile,
          member.place,
          member.district,
          member.constituency
        ].join(',')
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `pending-collections-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };
*/

  const exportToCSV = () => {
  const headers = ['S.No', 'KMCC ID', 'Name', 'Mobile', 'Place', 'District', 'Constituency','Receipt'];
  const csvContent = [
    headers.join(','),
    ...filteredMembers.map((member, index) => 
      [
        index + 1,
        member.kmccId,
        member.name,
        member.mobile,
        member.place,
        member.district,
        member.constituency,
        member.receipt
      ].join(',')
    )
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `pending-collections-${new Date().toISOString().split('T')[0]}.csv`;
  link.click();
};

  
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Approved by Me</h1>
          <p className="mt-1 text-gray-600">
            {/*View members with pending collections at constituency level*/}
          </p>
        </div>
        <div className="flex space-x-3">
          <button
            onClick={copyToClipboard}
            className={`flex items-center px-4 py-2 ${
              copied ? 'bg-green-600' : 'bg-gray-600'
            } text-white rounded-md hover:bg-opacity-90 transition-colors`}
          >
            {copied ? (
              <>
                <Check size={16} className="mr-2" />
                Copied!
              </>
            ) : (
              <>
                <Copy size={16} className="mr-2" />
                Copy to Clipboard
              </>
            )}
          </button>
          <button
            onClick={exportToCSV}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            <Download size={16} className="mr-2" />
            Export CSV
          </button>
        </div>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-red-700">{error}</p>
        </div>
      )}
   
      <div className="mb-8 bg-white rounded-lg shadow-md p-6">
         <div className="flex items-center mb-4">
          <Filter size={20} className="text-gray-500 mr-2" />
          <h2 className="text-lg font-semibold text-gray-700">Filters</h2>
        </div>
      <div className="flex flex-col md:flex-row gap-4">
     {/*   <div>
            <label htmlFor="district" className="block text-sm font-medium text-gray-700 mb-1">
              District
            </label>
            <select
              id="district"
              value={selectedDistrict}
              onChange={(e) => handleDistrictChange(e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors ${
                isConstituencyUser ? 'bg-gray-100' : ''
              }`}
              disabled={isLoading || isConstituencyUser}
            >
              {districts.map((district) => (
                <option key={district} value={district}>
                  {district}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="constituency" className="block text-sm font-medium text-gray-700 mb-1">
              Constituency
            </label>
            <select
              id="constituency"
              value={selectedConstituency}
              onChange={(e) => handleConstituencyChange(e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors ${
                isConstituencyUser ? 'bg-gray-100' : ''
              }`}
              disabled={isLoading || isConstituencyUser || constituencies.length === 0}
            >
              {(constituencies[selectedDistrict] || ['All']).map((constituency) => (
                <option key={constituency} value={constituency}>
                  {constituency}
                </option>
              ))}
            </select>
          </div>
*/}
          <div>
            <label htmlFor="search" className="block text-sm font-medium text-gray-700 mb-1">
              Search
            </label>
            <input
              type="text"
              id="search"
              value={searchTerm}
              onChange={handleSearch}
              placeholder="Search by ID, name, mobile..."
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
            />
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="h-64 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Sl
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Constituency
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    KMCC ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Mobile
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Place
                  </th>
                   <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Receipt
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Approved By
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    District By
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    State By
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {paginatedMembers.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-4 text-center text-gray-500">
                      No data found
                    </td>
                  </tr>
                ) : (
                  paginatedMembers.map((member, index) => (
                    <tr key={member.kmccId}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {index + 1}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {member.constituency}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {member.kmccId}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {member.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {member.mobile}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {member.place}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {member.receipt}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {member.approvedby}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {member.districtby}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {member.stateby}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {totalPages > 1 && (
        <div className="mt-4 flex items-center justify-between bg-white px-4 py-3 rounded-lg shadow-md">
          <div className="flex items-center">
            <p className="text-sm text-gray-700">
              Showing{' '}
              <span className="font-medium">{((currentPage - 1) * itemsPerPage) + 1}</span>
              {' '}-{' '}
              <span className="font-medium">
                {Math.min(currentPage * itemsPerPage, filteredMembers.length)}
              </span>
              {' '}of{' '}
              <span className="font-medium">{filteredMembers.length}</span>
              {' '}results
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Previous
            </button>
            <span className="px-3 py-1 text-sm text-gray-700">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default collectedbyme;