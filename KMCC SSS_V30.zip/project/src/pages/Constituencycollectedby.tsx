import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';

interface SummaryRow {
  constituency: string;
  approvedBy: string;
  approvedbyname: string;
  activeCount: number;
  col14Filled: number;
  col16Filled: number;
}

export default function Constituencycollectedby() {
  const { authState } = useAuth();
  const [summaryData, setSummaryData] = useState<SummaryRow[]>([]);
  const selectedConstituency = authState.user?.constituency || 'All';
  const selectedDistrict = authState.user?.district || 'All';
  //const [selectedDistrict, setSelectedDistrict] = useState<string>('All');

  
  const isConstituencyUser = authState.user?.type === 'Constituency';
  const isDistrictUser = authState.user?.type === 'District';

  useEffect(() => {
    const fetchData = async () => {
      try {
        const sheetId = '1Qp_PQ0WqkzweQoWhLoomDg8E2uM4foSVWS5UvoqTEyk';
        const gid = '805376514';

        const response = await fetch(
          `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:csv&gid=${gid}&timestamp=${Date.now()}`,
          { cache: 'no-store' }
        );

        const csv = await response.text();
        const rows = csv.split('\n').map(row => row.split(','));
        const data = rows.slice(2);

        const grouped = new Map<string, SummaryRow>();

        for (const row of data) {
          const constituency = (row[4]?.trim().replace(/^"|"$/g, '')) || '';
          const district = (row[3]?.trim().replace(/^"|"$/g, '')) || '';
          const approvedBy = (row[10]?.trim().replace(/^"|"$/g, '')) || '';
          const approvedbyname = (row[32]?.trim().replace(/^"|"$/g, '') || '');


        
          const status = (row[8]?.trim().replace(/^"|"$/g, '')) || '';
          const col14 = (row[14]?.trim().replace(/^"|"$/g, '')) || '';
          const col16 = (row[16]?.trim().replace(/^"|"$/g, '')) || '';


          if (isConstituencyUser) {
              if (status !== 'Active') continue;
              if (selectedConstituency !== 'All' && constituency !== selectedConstituency) continue;
              }
          else if  (isDistrictUser) {
              if (status !== 'Active') continue;
              if (district !== selectedDistrict) continue;
              }
          const key = `${constituency}||${approvedbyname}`;

          if (!grouped.has(key)) {
            grouped.set(key, {
              constituency,
              approvedBy,
              approvedbyname,
              activeCount: 0,
              col14Filled: 0,
              col16Filled: 0,
            });
          }

          const item = grouped.get(key)!;
          item.activeCount += 1;
          if (col14.length > 1) item.col14Filled += 1;
          if (col16.length > 1) item.col16Filled += 1;
        }
        const sortedData = Array.from(grouped.values()).sort((a, b) => {
          if (a.constituency < b.constituency) return -1;
          if (a.constituency > b.constituency) return 1;
          return b.activeCount - a.activeCount; // tie-breaker: descending activeCount
        });
     
        setSummaryData(sortedData);

        
        
        
                
        //setSummaryData(Array.from(grouped.values()));
      } catch (err) {
        console.error('Error fetching data:', err);
      }
    };

    fetchData();
  }, [selectedConstituency]);

      const totalActiveCount = summaryData.reduce((sum, item) => sum + item.activeCount, 0);
      const totalCol14 = summaryData.reduce((sum, item) => sum + item.col14Filled, 0);
      const totalCol16 = summaryData.reduce((sum, item) => sum + item.col16Filled, 0);
  

  return (
    <div className="max-w-7xl mx-auto p-6 bg-white rounded-lg shadow-md">
      <h1 className="text-3xl font-semibold mb-6 text-gray-800">Constituency Collected By Summary</h1>
      <p className="mb-4 text-lg">
        Selected Constituency:{' '}
        <span className="font-semibold text-indigo-600">{selectedConstituency}</span>
      </p>

      <div className="overflow-x-auto">
        <table className="min-w-full border border-gray-300 divide-y divide-gray-200">
          <thead className="bg-indigo-100">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-semibold text-indigo-900">Constituency</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-indigo-900">Approved By</th>
              <th className="px-4 py-3 text-center text-sm font-semibold text-indigo-900">Active Count</th>
              <th className="px-4 py-3 text-center text-sm font-semibold text-indigo-900">District Collected</th>
              <th className="px-4 py-3 text-center text-sm font-semibold text-indigo-900">State Collected</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 bg-white">
            {summaryData.length === 0 ? (
              <tr>
                <td colSpan={5} className="text-center py-8 text-gray-500 italic">
                  {/*No data found for constituency "{selectedConstituency}" */}
                   No data found for District "{selectedDistrict}" 
                </td>
              </tr>
            ) : (
              summaryData.map((item, idx) => (
                <tr
                  key={idx}
                  className="hover:bg-indigo-50 transition-colors duration-200 cursor-pointer"
                >
                     <td className="px-4 py-3 whitespace-nowrap text-gray-700">{item.constituency}</td>
                   <td
                  className={`px-4 py-3 whitespace-nowrap ${
                    item.approvedbyname && item.approvedbyname.trim().length >= 1
                      ? 'text-gray-700'
                      : 'text-red-600 font-semibold'
                  }`}
                >
                  {item.approvedbyname && item.approvedbyname.trim().length >= 1
                    ? `${item.approvedbyname}`
                    : 'Balance to Collect'}
                </td>
              
                  {/*   <td className="px-4 py-3 whitespace-nowrap text-center text-gray-700 font-medium">
                    {item.approvedBy} 
                  </td>
                  */}
                  <td className="px-4 py-3 whitespace-nowrap text-center text-gray-700 font-medium">
                    {item.activeCount}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-center text-gray-700 font-medium">
                    {item.col14Filled}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-center text-gray-700 font-medium">
                    {item.col16Filled}
                  </td>
                </tr>
              ))
      
            )}
            <tr className="bg-indigo-200 font-semibold text-indigo-900">
            <td className="px-4 py-3 text-right" colSpan={2}>Total</td>
            <td className="px-4 py-3 text-center">{totalActiveCount}</td>
            <td className="px-4 py-3 text-center">{totalCol14}</td>
            <td className="px-4 py-3 text-center">{totalCol16}</td>
            
          </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
