export interface User {
  id: string;
  password: string;
  type: string;
  district: string;
  constituency: string;
}

export interface KmccMember {
  kmccId: string;
  name: string;
  district: string;
  constituency: string;
  civilId: string;
  mobile: string;
  receipt?: string;
  collectedBy?: string;
  collectedTime?: string;
  remarks?: string;
  collectedmobile?: string;
}

export interface VerificationRecord {
  slNo: number;
  idNumber: string;
  name: string;
  dateTime: string;
  remarks: string;
  verifiedBy: string;
  receipt: string;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  member: KmccMember | null;
}